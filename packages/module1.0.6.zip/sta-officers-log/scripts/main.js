﻿import { CallbackRequestApp } from "./CallbackRequestApp.js";
import { MODULE_ID } from "./constants.js";
import { t } from "./i18n.js";
import { initSocket } from "./socket.js";
import {
  AMBIENT_AUDIO_SELECTION_ONLY_SETTING,
  installAmbientAudioSelectionListenerPatch,
  setPlayerAmbientAudioSelectionOnlyEnabled,
} from "./ambientAudioPatch.js";
import {
  addParticipantToCurrentMission,
  ensureNewSceneMacro,
  hasUsedCallbackThisMission,
  newScene,
  promptAddParticipant,
  promptNewMissionAndReset,
  registerMissionSettings,
  resetMissionCallbacks,
} from "./mission.js";
import {
  registerFocusPickerSettings,
  registerTalentPickerSettings,
} from "./focusPickerSettings.js";
import { getCharacterArcEligibility } from "./arcChains.js";
import {
  openGMFlow,
  promptCallbackForUserId,
  sendCallbackPromptToUser,
  openPendingShipBenefitsDialog,
} from "./callbackFlow.js";
import {
  installCreateChatMessageHook,
  installRenderApplicationV2Hook,
} from "./sheetHooks.js";
import { registerClientSettings } from "./clientSettings.js";
import { registerDirectiveSettings } from "./directives.js";

function registerApi() {
  // Public API (available on all clients; methods may GM-guard internally)
  game.staCallbacksHelper = {
    open: openGMFlow,
    resetMissionCallbacks,
    promptNewMissionAndReset,
    addParticipantToCurrentMission,
    promptAddParticipant,

    // Macro/tooling
    newScene,

    // Expose for socket + tools
    promptCallbackForUserId,
    sendCallbackPromptToUser,

    // Arc tooling
    getCharacterArcEligibility,

    // Small helper for hooks (cheap guard)
    hasUsedCallbackThisMission,

    // Ship benefits review
    reviewPendingShipBenefits: openPendingShipBenefitsDialog,
  };

  // Back-compat for macros that reference a global symbol.
  globalThis.staCallbacksHelper = game.staCallbacksHelper;
}

function safeInstallUiHooks() {
  try {
    installRenderApplicationV2Hook();
  } catch (err) {
    console.error(`${MODULE_ID} | failed to install render hook`, err);
  }
}

function safeInstallChatHooks() {
  try {
    installCreateChatMessageHook();
  } catch (err) {
    console.error(`${MODULE_ID} | failed to install chat hook`, err);
  }
}

function safeRegisterSettings() {
  try {
    registerMissionSettings();
  } catch (err) {
    console.error(`${MODULE_ID} | failed to register settings`, err);
  }

  try {
    registerDirectiveSettings();
  } catch (err) {
    console.error(`${MODULE_ID} | failed to register directive settings`, err);
  }

  try {
    registerFocusPickerSettings();
  } catch (err) {
    console.error(
      `${MODULE_ID} | failed to register focus picker settings`,
      err
    );
  }

  try {
    registerTalentPickerSettings();
  } catch (err) {
    console.error(
      `${MODULE_ID} | failed to register talent picker settings`,
      err
    );
  }
}

function safeRegisterClientSettings() {
  try {
    registerClientSettings();
  } catch (err) {
    console.error(`${MODULE_ID} | failed to register client settings`, err);
  }
}

function safeRegisterAmbientAudioSettings() {
  try {
    game.settings.register(MODULE_ID, AMBIENT_AUDIO_SELECTION_ONLY_SETTING, {
      name: t("sta-officers-log.settings.playerAmbientAudioSelectionOnly.name"),
      hint: t("sta-officers-log.settings.playerAmbientAudioSelectionOnly.hint"),
      scope: "world",
      config: true,
      type: Boolean,
      default: false,
      onChange: (value) => {
        try {
          setPlayerAmbientAudioSelectionOnlyEnabled(Boolean(value));
        } catch (err) {
          console.error(
            `${MODULE_ID} | ambient audio setting onChange failed`,
            err
          );
        }
      },
    });
  } catch (err) {
    console.error(
      `${MODULE_ID} | failed to register ambient audio settings`,
      err
    );
  }
}

function safeInitSocket() {
  try {
    initSocket({ CallbackRequestApp });
  } catch (err) {
    console.error(`${MODULE_ID} | initSocket failed`, err);
  }
}

function refreshSceneControls() {
  try {
    // If controls were already built before our hook registered, force refresh.
    ui.controls?.initialize?.();
  } catch (_) {
    // ignore
  }
}

/**
 * One-time migration: copy world settings data (callback usage, mission logs) to actor flags.
 * TODO (May 2026): Remove this migration code after transition period
 */
async function migrateWorldSettingsToActorFlags() {
  // Only GM can set world settings
  if (!game.user.isGM) {
    return;
  }

  const migrationKey = "worldSettingsToActorFlagsMigration";
  const migrated = game.settings.get(MODULE_ID, migrationKey);

  if (migrated) {
    // Migration already completed
    return;
  }

  console.log(
    `${MODULE_ID} | Running one-time migration: world settings → actor flags`
  );

  try {
    // Get world settings data
    const callbackUsedMap =
      game.settings.get(MODULE_ID, "missionCallbackUsed") ?? {};
    const missionLogMap =
      game.settings.get(MODULE_ID, "missionLogByUser") ?? {};

    // Migrate to actor flags
    const updates = [];
    for (const actor of game.actors) {
      if (actor.type !== "character") continue;

      // Find the user who owns this actor
      const userId = Object.keys(actor.ownership || {}).find(
        (uid) =>
          uid !== "default" &&
          actor.ownership[uid] === CONST.DOCUMENT_OWNERSHIP_LEVELS.OWNER
      );

      if (!userId) continue;

      // Migrate callback usage
      const hasUsed = Boolean(callbackUsedMap[userId]);
      if (hasUsed && !actor.getFlag(MODULE_ID, "usedCallbackThisMission")) {
        updates.push(actor.setFlag(MODULE_ID, "usedCallbackThisMission", true));
      }

      // Migrate mission log
      const logId = missionLogMap[userId];
      if (logId && !actor.getFlag(MODULE_ID, "currentMissionLogId")) {
        updates.push(
          actor.setFlag(MODULE_ID, "currentMissionLogId", String(logId))
        );
      }
    }

    await Promise.allSettled(updates);

    // Mark migration as complete
    await game.settings.set(MODULE_ID, migrationKey, true);

    console.log(
      `${MODULE_ID} | Migration complete: ${updates.length} actors updated`
    );
  } catch (err) {
    console.error(`${MODULE_ID} | Migration failed:`, err);
  }
}

/**
 * Check all actors for pending ship benefits and notify GM if any exist
 */
async function checkPendingShipBenefits() {
  try {
    let totalPending = 0;

    for (const actor of game.actors) {
      if (actor.type !== "character") continue;

      const pending = actor.getFlag(MODULE_ID, "pendingShipBenefits");
      if (pending && Array.isArray(pending) && pending.length > 0) {
        totalPending += pending.length;
      }
    }

    if (totalPending > 0) {
      const notification = ui.notifications.info(
        `${totalPending} pending ship benefit${
          totalPending === 1 ? "" : "s"
        } to review. Click here to review them.`,
        { permanent: true }
      );

      // Make the notification clickable
      if (notification?.element) {
        notification.element.style.cursor = "pointer";
        notification.element.addEventListener("click", () => {
          openPendingShipBenefitsDialog();
          notification.close();
        });
      }
    }
  } catch (err) {
    console.error(`${MODULE_ID} | checkPendingShipBenefits failed:`, err);
  }
}

// Ensure API exists even if init/ready already fired (late-load resilience)
try {
  registerApi();
} catch (err) {
  console.error(`${MODULE_ID} | failed to register API`, err);
}

Hooks.once("init", () => {
  safeRegisterClientSettings();
  safeRegisterSettings();
  safeRegisterAmbientAudioSettings();
  installAmbientAudioSelectionListenerPatch();

  // Public API (refresh in case something overwrote it)
  registerApi();

  console.log(
    "sta-officers-log | API registered: game.staCallbacksHelper.open()"
  );

  // Hooks moved out of main.js
  safeInstallUiHooks();
});

Hooks.once("ready", () => {
  console.log(
    `${MODULE_ID} | ready on ${game.user.name} | id=${game.user.id} | GM? ${game.user.isGM}`
  );

  safeInitSocket();

  try {
    if (game.user.isGM) ensureNewSceneMacro();
  } catch (err) {
    console.error(`${MODULE_ID} | ensureNewSceneMacro failed`, err);
  }

  // Migrate world settings to actor flags (one-time migration)
  // TODO (May 2026): Remove this migration code after transition period
  try {
    migrateWorldSettingsToActorFlags();
  } catch (err) {
    console.error(`${MODULE_ID} | migration failed`, err);
  }

  // Check for pending ship benefits and notify GM
  try {
    if (game.user.isGM) checkPendingShipBenefits();
  } catch (err) {
    console.error(`${MODULE_ID} | checkPendingShipBenefits failed`, err);
  }

  // Hooks moved out of main.js
  safeInstallChatHooks();
});

// If the module was loaded after init/ready already fired, run best-effort setup.
// This should be rare, but it prevents a "everything is undefined" failure mode.
if (game?.ready) {
  safeRegisterClientSettings();
  safeRegisterSettings();
  safeRegisterAmbientAudioSettings();
  installAmbientAudioSelectionListenerPatch();
  safeInstallUiHooks();
  safeInstallChatHooks();
  safeInitSocket();
  refreshSceneControls();
}
