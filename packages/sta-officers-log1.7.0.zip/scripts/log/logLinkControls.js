import { MODULE_ID } from "../core/constants.js";
import { isPlainObject, escapeHTML } from "../core/utils.js";
import {
  STA_DEFAULT_ICON,
  getStaDefaultIcon,
  getValueStateArray,
  isValueInvokedState,
  mergeValueStateArray,
} from "../values/values.js";
import { isLogUsed } from "../missions/mission.js";
import { isCallbackTargetCompatibleWithValue } from "../callback/callbackEligibility.js";
import { t } from "../core/i18n.js";
import {
  DIRECTIVE_VALUE_ID_PREFIX,
  NO_VALUE_USED_ID,
  directiveIconPath,
  getDirectiveKeyFromValueId,
  getDirectiveSnapshotForLog,
  getDirectiveTextForValueId,
  getMissionDirectives,
  isDirectiveValueId,
  isNoValueUsedId,
  makeDirectiveKeyFromText,
  makeDirectiveValueIdFromText,
  sanitizeDirectiveText,
} from "../directives/directives.js";
import {
  computeBestChainEndingAt,
  getCallbackLogEdgesForValue,
} from "../arcs/arcChains.js";
import { canCurrentUserChangeActor } from "../core/utils.js";
import { refreshMissionLogSortingForActorId } from "./logSorting.js";
import {
  getCompletedArcEndLogIds,
  getLogSortKey,
  getPrimaryValueIdForLog,
} from "./logSorting.js";

async function _syncLogImgToValue(actor, log, valueId) {
  const vId = valueId ? String(valueId) : "";
  if (!actor || actor.type !== "character") return;
  if (!log || log.type !== "log") return;

  if (vId && isDirectiveValueId(vId)) {
    const icon = directiveIconPath();
    if (icon && String(log.img ?? "") !== String(icon)) {
      try {
        await log.update({ img: icon }, { render: false, renderSheet: false });
      } catch (_) {
        // ignore
      }
    }
    return;
  }

  // If no value is selected, restore STA default.
  if (!vId) {
    const def = getStaDefaultIcon?.() || STA_DEFAULT_ICON;
    if (def && String(log.img ?? "") !== String(def)) {
      try {
        await log.update({ img: def }, { render: false, renderSheet: false });
      } catch (_) {
        // ignore
      }
    }
    return;
  }

  const valueItem = vId ? actor.items.get(vId) : null;
  const desiredImg =
    valueItem?.type === "value" && valueItem?.img ? String(valueItem.img) : "";

  if (desiredImg && log.img !== desiredImg) {
    try {
      await log.update(
        { img: desiredImg },
        { render: false, renderSheet: false },
      );
    } catch (_) {
      // ignore
    }
  }
}

const flagPath = (key) => `flags.${MODULE_ID}.${key}`;

async function setFlagWithoutRender(log, key, value) {
  if (!log || typeof log.update !== "function") return;
  await log.update(
    { [flagPath(key)]: value },
    { render: false, renderSheet: false },
  );
}

async function unsetFlagWithoutRender(log, key) {
  if (!log || typeof log.update !== "function") return;
  // Foundry does not reliably delete properties when setting `undefined`.
  // Use `null` to unset flags.
  await log.update(
    { [flagPath(key)]: null },
    { render: false, renderSheet: false },
  );
}

/**
 * After manually linking a source log to a target, ensure the source has an
 * invoked value state that matches the target's chain value.  If it doesn't,
 * prompt the user to confirm which value they used and set it to "positive".
 */
async function _ensureSourceHasMatchingValueState(
  actor,
  sourceLog,
  targetLogId,
) {
  const targetLog = actor.items.get(String(targetLogId));
  if (!targetLog || targetLog.type !== "log") return;

  const values = actor.items.filter((i) => i?.type === "value");
  const targetPrimary = getPrimaryValueIdForLog(actor, targetLog, values);

  if (targetPrimary) {
    // Target has a known chain value — check if source already has an invoked state.
    const srcStates = getValueStateArray(sourceLog, targetPrimary);
    if (srcStates.some(isValueInvokedState)) return; // Already good.

    const targetValue = values.find((v) => String(v.id) === targetPrimary);
    const valueName = targetValue?.name ?? "this value";

    const confirmed = await foundry.applications.api.DialogV2.confirm({
      window: {
        title:
          t("sta-officers-log.flowchart.pickValueTitle") ?? "Confirm Value",
      },
      content: `<p>The target log's chain value is <strong>${escapeHTML(valueName)}</strong>. Did you use this value?</p>`,
      yes: { label: t("Yes") ?? "Yes" },
      no: { label: t("No") ?? "No" },
      rejectClose: false,
    });

    if (confirmed) {
      const existing = getValueStateArray(sourceLog, targetPrimary).filter(
        (s) => s !== "unused",
      );
      if (!existing.some(isValueInvokedState)) {
        const newStates =
          existing.length > 0 ? [...existing, "positive"] : ["positive"];
        await sourceLog.update({
          [`system.valueStates.${targetPrimary}`]: newStates,
        });
      }
    }
  } else {
    // Target has no primary — collect its invoked values and let the user pick.
    const targetInvoked = [];
    for (const v of values) {
      const pStates = getValueStateArray(targetLog, v.id);
      if (pStates.some(isValueInvokedState)) targetInvoked.push(v);
    }
    if (targetInvoked.length === 0) return; // Nothing to match against.

    // Check if source already overlaps.
    const alreadyOverlaps = targetInvoked.some((v) => {
      const srcStates = getValueStateArray(sourceLog, v.id);
      return srcStates.some(isValueInvokedState);
    });
    if (alreadyOverlaps) return;

    const choiceHTML = targetInvoked
      .map(
        (v) =>
          `<label style="display:block;margin:4px 0;">
            <input type="radio" name="valueId" value="${escapeHTML(v.id)}" />
            <span>${escapeHTML(v.name)}</span>
          </label>`,
      )
      .join("");

    const pickedValueId = await foundry.applications.api.DialogV2.prompt({
      window: {
        title: t("sta-officers-log.flowchart.pickValueTitle") ?? "Choose Value",
      },
      content: `
        <p>${t("sta-officers-log.flowchart.pickValueMessage") ?? "Which of the target log's values did you use?"}</p>
        <div>${choiceHTML}</div>
      `,
      ok: {
        label: t("sta-officers-log.flowchart.useValue") ?? "Use Value",
        callback: (_event, button) => {
          return button.form?.elements?.valueId?.value || null;
        },
      },
      rejectClose: false,
    });

    if (pickedValueId) {
      const existing = getValueStateArray(sourceLog, pickedValueId).filter(
        (s) => s !== "unused",
      );
      if (!existing.some(isValueInvokedState)) {
        const newStates =
          existing.length > 0 ? [...existing, "positive"] : ["positive"];
        await sourceLog.update({
          [`system.valueStates.${pickedValueId}`]: newStates,
        });
      }
    }
  }
}

export async function promptLinkLogToChain({ actor, log }) {
  if (!actor || actor.type !== "character") return;
  if (!log || log.type !== "log") return;
  if (!canCurrentUserChangeActor(actor)) return;

  const logs = actor.items.filter((i) => i?.type === "log");
  const values = actor.items.filter((i) => i?.type === "value");

  const existing = log.getFlag?.(MODULE_ID, "callbackLink") ?? {};
  const existingFrom = String(existing?.fromLogId ?? "");
  const existingValue = String(existing?.valueId ?? "");

  const logOptions = logs
    .filter((l) => String(l.id) !== String(log.id))
    .filter((l) => !isLogUsed(l) || String(l.id) === existingFrom)
    .map((l) => {
      const sel = String(l.id) === existingFrom ? " selected" : "";
      return `<option value="${escapeHTML(l.id)}"${sel}>${escapeHTML(
        l.name,
      )}</option>`;
    })
    .join("");

  const valueOptions = values
    .map((v) => {
      const sel = String(v.id) === existingValue ? " selected" : "";
      const icon = v?.img ? String(v.img) : "";
      // Best-effort: show icon in the dropdown option (works in Chromium in many cases).
      const style = icon
        ? ` style="background-image:url('${escapeHTML(
            icon,
          )}');background-repeat:no-repeat;background-position:4px 50%;background-size:16px 16px;padding-left:24px;"`
        : "";
      return `<option value="${escapeHTML(v.id)}"${sel}${style}>${escapeHTML(
        v.name,
      )}</option>`;
    })
    .join("");

  const res = await foundry.applications.api.DialogV2.wait({
    window: { title: "Link Log to Chain" },
    content: `
      <div class="form-group">
        <label>Link <strong>${escapeHTML(
          log.name ?? "Log",
        )}</strong> as a callback to:</label>
        <select name="fromLogId">
          <option value="">- (No link)</option>
          ${logOptions}
        </select>
        <p class="hint">Choose the earlier log this one calls back to.</p>
      </div>

      <div class="form-group">
        <label>Value (optional):</label>
        <select name="valueId">
          <option value="">-</option>
          ${valueOptions}
        </select>
      </div>
    `,
    buttons: [
      {
        action: "save",
        label: "Save",
        default: true,
        callback: (_event, button) => {
          const form = button.form;
          return {
            fromLogId: String(form?.elements?.fromLogId?.value ?? ""),
            valueId: String(form?.elements?.valueId?.value ?? ""),
          };
        },
      },
      { action: "cancel", label: "Cancel" },
    ],
    rejectClose: false,
    modal: false,
  });

  if (!res || res === "cancel") return;

  const fromLogId = String(res.fromLogId ?? "");
  const valueId = String(res.valueId ?? "");

  // Enforce: cannot call back to a log that is already used (unless it's the existing selection).
  if (fromLogId && fromLogId !== existingFrom) {
    const target = actor.items.get(String(fromLogId));
    if (target?.type === "log" && isLogUsed(target)) {
      ui.notifications?.warn?.(
        "That log has already been used for a callback.",
      );
      return;
    }
  }

  if (!fromLogId) {
    await unsetFlagWithoutRender(log, "callbackLink");

    // Mark an explicit override so milestone-derived edges don't keep it in a chain.
    try {
      await setFlagWithoutRender(log, "callbackLinkDisabled", true);
    } catch (_) {
      // ignore
    }

    // Still allow the user to change the icon via the Value dropdown.
    await _syncLogImgToValue(actor, log, valueId);
  } else {
    // Clear explicit override when setting a link.
    try {
      await unsetFlagWithoutRender(log, "callbackLinkDisabled");
    } catch (_) {
      // ignore
    }

    await setFlagWithoutRender(log, "callbackLink", { fromLogId, valueId });

    // Align the log's icon to the selected value (or restore STA default).
    await _syncLogImgToValue(actor, log, valueId);

    // Ensure the source log has an invoked value state that matches the
    // target's chain value so that chain-indent validation passes.
    await _ensureSourceHasMatchingValueState(actor, log, fromLogId);
  }

  // Update any open character sheets so chain sorting/indentation refreshes.
  rerenderOpenStaSheetsForActorId(actor.id);
}

export function installInlineLogChainLinkControls(root, actor, log) {
  // Remove the old header button (we now do this inline in the sheet).
  try {
    root
      ?.querySelector?.("header.window-header .sta-link-chain-btn")
      ?.remove?.();
  } catch (_) {
    // ignore
  }

  const canChange = canCurrentUserChangeActor(actor);

  // If the user can't change, ensure our injected controls are removed.
  if (!canChange) {
    root?.querySelector?.(".sta-log-link-controls")?.remove?.();
    return;
  }

  const sheetRoot =
    root?.querySelector?.('.item-sheet[data-application-part="itemsheet"]') ||
    root?.querySelector?.(".item-sheet") ||
    null;
  if (!sheetRoot) return;

  // We insert into the sheet's <form> when present, so don't require direct-child.
  if (sheetRoot.querySelector(".sta-log-link-controls")) return;

  const logs = actor.items
    .filter((i) => i?.type === "log")
    .filter((l) => String(l.id) !== String(log.id))
    .slice()
    .sort((a, b) => {
      const d = getLogSortKey(a) - getLogSortKey(b);
      if (d) return d;
      return String(a.name ?? "").localeCompare(
        String(b.name ?? ""),
        undefined,
        {
          sensitivity: "base",
        },
      );
    });

  const values = Array.from(actor.items ?? [])
    .filter((i) => i?.type === "value")
    .slice()
    .sort((a, b) => {
      const d = Number(a.sort ?? 0) - Number(b.sort ?? 0);
      if (d) return d;
      return String(a.name ?? "").localeCompare(
        String(b.name ?? ""),
        undefined,
        {
          sensitivity: "base",
        },
      );
    });

  const existing = log.getFlag?.(MODULE_ID, "callbackLink") ?? {};
  const existingFrom = String(existing?.fromLogId ?? "");
  const existingValue = String(existing?.valueId ?? "");
  const existingMilestoneId = String(existing?.milestoneId ?? "");
  const isDisabled = log.getFlag?.(MODULE_ID, "callbackLinkDisabled") === true;

  const persistedPrimary = String(
    log.getFlag?.(MODULE_ID, "primaryValueId") ?? "",
  );

  const directivesSnapshot = (() => {
    const snap = getDirectiveSnapshotForLog(log);
    return snap.length ? snap : getMissionDirectives();
  })();
  const directivesByKey = new Map();
  for (const d of directivesSnapshot) {
    const text = sanitizeDirectiveText(d);
    if (!text) continue;
    const key = makeDirectiveKeyFromText(text);
    if (!key) continue;
    directivesByKey.set(key, text);
  }

  // Also include any directives already present on this log, so they can be
  // selected as Primary even if they are not in the current mission list.
  try {
    const existingLabels = log.getFlag?.(MODULE_ID, "directiveLabels") ?? {};
    if (isPlainObject(existingLabels)) {
      for (const [k, v] of Object.entries(existingLabels)) {
        const key = String(k ?? "");
        const text = sanitizeDirectiveText(v ?? "");
        if (!key || !text) continue;
        if (!directivesByKey.has(key)) directivesByKey.set(key, text);
      }
    }
  } catch (_) {
    // ignore
  }

  try {
    const states = log?.system?.valueStates ?? {};
    for (const [valueId, state] of Object.entries(states)) {
      if (String(state) === "unused") continue;
      if (!isDirectiveValueId(valueId)) continue;
      const key = getDirectiveKeyFromValueId(valueId);
      if (!key) continue;
      if (directivesByKey.has(String(key))) continue;
      const text = sanitizeDirectiveText(
        getDirectiveTextForValueId(log, valueId),
      );
      if (text) directivesByKey.set(String(key), text);
    }
  } catch (_) {
    // ignore
  }

  const existingArcInfo = log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
  const isArcEnd = existingArcInfo?.isArc === true;
  const existingArcValueId = String(existingArcInfo?.valueId ?? "");
  const existingArcStepsRaw = Number(existingArcInfo?.steps ?? 0);
  const existingArcSteps = Number.isFinite(existingArcStepsRaw)
    ? existingArcStepsRaw
    : 0;
  const existingArcChainLen = Array.isArray(existingArcInfo?.chainLogIds)
    ? existingArcInfo.chainLogIds.length
    : 0;
  const initialArcSteps = Math.max(
    1,
    existingArcSteps || existingArcChainLen || 3,
  );

  const selectedFromLogId = isDisabled ? "" : existingFrom;
  // Prefer the explicit Primary Value selection.
  const selectedValueId = persistedPrimary || existingValue;

  let _baselineFromLogId = String(selectedFromLogId);
  let _baselineValueId = String(selectedValueId);
  let _baselineIsArcEnd = Boolean(isArcEnd);
  let _baselineArcSteps = Number.isFinite(Number(initialArcSteps))
    ? Number(initialArcSteps)
    : 1;
  let _baselineArcValueId = String(
    existingArcValueId || existingValue || selectedValueId || "",
  );

  const completedArcEndLogIds = getCompletedArcEndLogIds(actor);

  const isEligibleFromLogId = (targetLogId, currentValueId) => {
    const tId = targetLogId ? String(targetLogId) : "";
    const vId = currentValueId ? String(currentValueId) : "";
    if (!tId) return true;

    // Prevent linking to logs that have already been used for a callback.
    // Keep the current selection available so existing data isn't broken.
    // Keep the *saved* selection available so existing data isn't broken.
    if (tId !== String(_baselineFromLogId)) {
      const usedTarget = actor.items.get(tId);
      if (usedTarget?.type === "log" && isLogUsed(usedTarget)) return false;
    }

    const target = actor.items.get(tId);
    if (!target || target.type !== "log") return false;
    const targetPrimary = getPrimaryValueIdForLog(actor, target, values);

    return isCallbackTargetCompatibleWithValue({
      valueId: vId,
      targetPrimaryValueId: targetPrimary,
      isCompletedArcEnd: completedArcEndLogIds.has(tId),
    });
  };

  const buildFromOptionsHtml = (currentValueId) => {
    const vId = currentValueId ? String(currentValueId) : "";
    const options = [];
    options.push('<option value="">- (No link)</option>');

    for (const l of logs) {
      const id = String(l.id);
      const eligible = isEligibleFromLogId(id, vId);
      if (!eligible && id !== String(_baselineFromLogId)) continue;

      const sel = id === String(selectedFromLogId) ? " selected" : "";

      // Never disable the currently-saved selection, otherwise the browser
      // may drop it on initial render (which can then get persisted).
      const isBaseline = id === String(_baselineFromLogId);
      const disabled = eligible || isBaseline ? "" : " disabled";
      const suffix = eligible
        ? ""
        : isLogUsed(l)
          ? " (already used)"
          : vId
            ? " (different primary value)"
            : "";

      options.push(
        `<option value="${escapeHTML(id)}"${sel}${disabled}>${escapeHTML(
          String(l.name ?? "") + suffix,
        )}</option>`,
      );
    }

    return options.join("");
  };

  const buildPrimaryValueOptionsHtml = (currentValueId) => {
    const curId = currentValueId ? String(currentValueId) : "";
    const options = [];

    const emptySel = !curId ? " selected" : "";
    options.push(`<option value=""${emptySel}>-</option>`);

    // "No Value Used" option (for organizational purposes)
    const noValueSel = curId === NO_VALUE_USED_ID ? " selected" : "";
    const noValueLabel = t("sta-officers-log.logSheet.noValueUsed");
    options.push(
      `<option value="${escapeHTML(NO_VALUE_USED_ID)}"${noValueSel}>${escapeHTML(noValueLabel)}</option>`,
    );

    // Values first
    for (const v of values) {
      const id = String(v.id);
      const sel = id === curId ? " selected" : "";
      options.push(
        `<option value="${escapeHTML(id)}"${sel}>${escapeHTML(
          String(v.name ?? ""),
        )}</option>`,
      );
    }

    // Directives section
    const directiveOptions = [];
    const seenDirectiveValueIds = new Set();

    for (const [key, text] of directivesByKey.entries()) {
      const valueId = `${DIRECTIVE_VALUE_ID_PREFIX}${String(key)}`;
      seenDirectiveValueIds.add(String(valueId));
      const sel = String(valueId) === curId ? " selected" : "";
      directiveOptions.push(
        `<option value="${escapeHTML(valueId)}"${sel}>${escapeHTML(
          String(text ?? valueId),
        )}</option>`,
      );
    }

    // Ensure the currently-selected directive displays even if it isn't in the current directives list.
    if (
      curId &&
      isDirectiveValueId(curId) &&
      !seenDirectiveValueIds.has(curId)
    ) {
      const label =
        sanitizeDirectiveText(getDirectiveTextForValueId(log, curId)) || curId;
      directiveOptions.unshift(
        `<option value="${escapeHTML(curId)}" selected>${escapeHTML(
          label,
        )}</option>`,
      );
    }

    // Always show the directives section separator.
    options.push('<option value="" disabled>--Directives--</option>');
    if (directiveOptions.length) options.push(directiveOptions.join(""));

    return options.join("");
  };

  // Build milestone options for the milestone select
  const buildMilestoneOptionsHtml = () => {
    const milestones = actor.items
      .filter((i) => i?.type === "milestone")
      .sort((a, b) => String(a.name ?? "").localeCompare(String(b.name ?? "")));

    const options = ['<option value="">— None —</option>'];
    for (const ms of milestones) {
      const msId = String(ms.id ?? "");
      const msName = String(ms.name ?? "").trim() || msId;
      const sel = msId === existingMilestoneId ? " selected" : "";
      options.push(
        `<option value="${escapeHTML(msId)}"${sel}>${escapeHTML(msName)}</option>`,
      );
    }
    return options.join("");
  };

  const wrapper = document.createElement("div");
  wrapper.className = "sta-log-link-controls";
  wrapper.innerHTML = `
    <input type="hidden" data-sta-callbacks-field="callbackLinkValueId" value="${escapeHTML(
      String(selectedValueId),
    )}" />
    <input type="hidden" data-sta-callbacks-field="arcValueId" value="${escapeHTML(
      String(existingArcValueId || existingValue || selectedValueId || ""),
    )}" />
    <div class="sta-log-link-row">
      <div class="column">
        <div class="title">Calls back to:</div>
        <select data-sta-callbacks-field="fromLogId">
          ${buildFromOptionsHtml(selectedValueId)}
        </select>
      </div>
      <div class="column">
        <div class="title">Primary Value</div>
        <select data-sta-callbacks-field="valueId">
          ${buildPrimaryValueOptionsHtml(selectedValueId)}
        </select>
      </div>
    </div>
    <div class="sta-log-link-row sta-log-arc-row">
      <div class="column sta-milestone-select-wrapper">
        <div class="title">Milestone</div>
        <select data-sta-callbacks-field="callbackLinkMilestoneId" title="Associate a Milestone/Arc with this log's callbackLink metadata">
          ${buildMilestoneOptionsHtml()}
        </select>
      </div>
      <div class="column sta-arc-column">
        <div class="title">Arc</div>
        <div class="sta-arc-fields">
          <label class="sta-arc-toggle">
            <input type="checkbox" data-sta-callbacks-field="isArcEnd" ${
              isArcEnd ? "checked" : ""
            } />
            <span>${escapeHTML(t("sta-officers-log.logSheet.arcComplete"))}</span>
          </label>
          <label class="sta-arc-steps">
            <span class="sta-arc-label">Steps</span>
            <input type="number" data-sta-callbacks-field="arcSteps" min="1" step="1" value="${escapeHTML(
              String(initialArcSteps),
            )}" />
          </label>
        </div>
      </div>
    </div>
  `;

  const formRoot = sheetRoot.querySelector("form") ?? sheetRoot;
  const firstRowInForm = formRoot.querySelector(":scope > .row");
  const insertBeforeInForm = firstRowInForm?.nextElementSibling ?? null;
  if (insertBeforeInForm) formRoot.insertBefore(wrapper, insertBeforeInForm);
  else formRoot.prepend(wrapper);

  const fromSelect = wrapper.querySelector(
    'select[data-sta-callbacks-field="fromLogId"]',
  );
  const valueSelect = wrapper.querySelector(
    'select[data-sta-callbacks-field="valueId"]',
  );
  const milestoneSelect = wrapper.querySelector(
    'select[data-sta-callbacks-field="callbackLinkMilestoneId"]',
  );
  const arcToggle = wrapper.querySelector(
    'input[data-sta-callbacks-field="isArcEnd"]',
  );
  const arcStepsInput = wrapper.querySelector(
    'input[data-sta-callbacks-field="arcSteps"]',
  );
  const callbackLinkValueIdInput = wrapper.querySelector(
    'input[data-sta-callbacks-field="callbackLinkValueId"]',
  );
  const arcValueIdInput = wrapper.querySelector(
    'input[data-sta-callbacks-field="arcValueId"]',
  );
  if (!(fromSelect instanceof HTMLSelectElement)) return;
  if (!(valueSelect instanceof HTMLSelectElement)) return;
  if (!(milestoneSelect instanceof HTMLSelectElement)) return;
  if (!(arcToggle instanceof HTMLInputElement)) return;
  if (!(arcStepsInput instanceof HTMLInputElement)) return;
  if (!(callbackLinkValueIdInput instanceof HTMLInputElement)) return;
  if (!(arcValueIdInput instanceof HTMLInputElement)) return;

  if (wrapper.dataset.staBound === "1") return;
  wrapper.dataset.staBound = "1";

  const getEffectiveValueId = () => {
    return String(valueSelect.value ?? "");
  };

  const ensurePrimaryValueOptionExists = (valueId, label) => {
    const vId = valueId ? String(valueId) : "";
    if (!vId) return;
    const exists = Array.from(valueSelect.options).some(
      (o) => String(o.value) === vId,
    );
    if (exists) return;

    if (!isDirectiveValueId(vId)) return;

    const safeLabel = sanitizeDirectiveText(label ?? "") || vId;
    const opt = document.createElement("option");
    opt.value = vId;
    opt.textContent = safeLabel;

    // Insert after the "--Directives--" separator if present.
    const sep = Array.from(valueSelect.options).find(
      (o) => o.disabled && String(o.textContent ?? "").includes("Directives"),
    );
    if (sep) {
      try {
        sep.after(opt);
        return;
      } catch (_) {
        // ignore
      }
    }

    valueSelect.appendChild(opt);
  };

  const refreshFromOptions = () => {
    const curVal = String(getEffectiveValueId() ?? "");
    const existingSel = String(fromSelect.value ?? "");
    fromSelect.innerHTML = buildFromOptionsHtml(curVal);

    // If the previous selection is still present, keep it; otherwise reset.
    const stillExists = Array.from(fromSelect.options).some(
      (o) => String(o.value) === existingSel,
    );
    if (stillExists) fromSelect.value = existingSel;
    else fromSelect.value = "";
  };

  const alignPrimaryValueToCallbackTarget = () => {
    const fromLogId = String(fromSelect.value ?? "");
    if (!fromLogId) return;

    // Exception: when calling back to the end of a completed arc, do NOT
    // auto-set the Primary Value. The new log is not part of that arc.
    if (completedArcEndLogIds?.has?.(fromLogId)) return;

    const target = actor.items.get(fromLogId);
    if (!target || target.type !== "log") return;

    const targetPrimaryValueId = String(
      getPrimaryValueIdForLog(actor, target, values) ?? "",
    );
    if (!targetPrimaryValueId) return;

    if (isDirectiveValueId(targetPrimaryValueId)) {
      const label =
        getDirectiveTextForValueId(log, targetPrimaryValueId) ||
        getDirectiveTextForValueId(target, targetPrimaryValueId) ||
        targetPrimaryValueId;
      ensurePrimaryValueOptionExists(targetPrimaryValueId, label);
    }

    const optionExists = Array.from(valueSelect.options).some(
      (o) => String(o.value) === targetPrimaryValueId,
    );
    if (!optionExists) return;

    if (String(valueSelect.value ?? "") === targetPrimaryValueId) return;
    valueSelect.value = targetPrimaryValueId;

    refreshFromOptions();
  };

  const syncFormFields = () => {
    let fromLogId = String(fromSelect.value ?? "");
    const valueId = String(getEffectiveValueId() ?? "");
    const wantsArcEnd = arcToggle.checked === true;

    const parseSteps = () => {
      const n = Number(arcStepsInput.value ?? 0);
      if (!Number.isFinite(n) || n <= 0) return 1;
      return Math.floor(n);
    };

    // Enforce: cannot call back to a log with a different primary value,
    // unless that log is the last log in a completed arc chain.
    if (fromLogId && valueId && !isEligibleFromLogId(fromLogId, valueId)) {
      ui.notifications?.warn(
        "Cannot call back to a log with a different primary value.",
      );
      fromSelect.value = "";
      fromLogId = "";
    }

    // "No Value Used" logs cannot form callback chains.
    if (fromLogId && isNoValueUsedId(valueId)) {
      fromSelect.value = "";
      fromLogId = "";
    }

    // Enforce: cannot call back to a log that is already used.
    // BUT: allow the currently-saved selection (grandfathered) so opening a log
    // cannot auto-clear its existing callback link.
    if (fromLogId && String(fromLogId) !== String(_baselineFromLogId)) {
      const target = actor.items.get(String(fromLogId));
      if (target?.type === "log" && isLogUsed(target)) {
        ui.notifications?.warn?.(
          "That log has already been used for a callback.",
        );
        fromSelect.value = "";
        fromLogId = "";
      }
    }

    // Keep callbackLink.valueId in sync with Primary Value.
    callbackLinkValueIdInput.value = valueId;

    // Arc end toggle: requires a stable Primary Value (and not "No Value Used").
    if (wantsArcEnd) {
      const arcValueId = valueId || _baselineArcValueId;
      if (!arcValueId || isNoValueUsedId(arcValueId)) {
        ui.notifications?.warn?.(
          isNoValueUsedId(arcValueId)
            ? "Cannot mark an Arc end for 'No Value Used' logs."
            : "Select a Primary Value before marking an Arc end.",
        );
        arcToggle.checked = false;
      } else {
        arcValueIdInput.value = String(arcValueId);
        arcStepsInput.value = String(parseSteps());
      }
    } else {
      // Still keep a reasonable valueId in the hidden field, but arcInfo.isArc will submit false.
      arcValueIdInput.value = String(_baselineArcValueId || valueId || "");
    }
  };

  let _saveInFlight = false;

  const scheduleSave = foundry.utils.debounce(() => void persistNow(), 150);

  const persistNow = async () => {
    if (_saveInFlight) return;
    _saveInFlight = true;

    // Ensure hidden fields represent the current UI.
    syncFormFields();

    let fromLogId = String(fromSelect.value ?? "");
    const valueId = String(getEffectiveValueId() ?? "");
    const wantsArcEnd = arcToggle.checked === true;
    const stepsRaw = Number(arcStepsInput.value ?? 0);
    const steps =
      Number.isFinite(stepsRaw) && stepsRaw > 0 ? Math.floor(stepsRaw) : 1;
    const arcValueId = String(arcValueIdInput.value ?? "");

    if (wantsArcEnd && (!arcValueId || isNoValueUsedId(arcValueId))) {
      ui.notifications?.warn?.(
        isNoValueUsedId(arcValueId)
          ? "Cannot mark an Arc end for 'No Value Used' logs."
          : "Select a Primary Value before marking an Arc end.",
      );
      return;
    }

    const update = {};

    // Primary Value
    update[`flags.${MODULE_ID}.primaryValueId`] = valueId ? valueId : null;

    // Directive metadata for editing/display
    if (valueId && isDirectiveValueId(valueId)) {
      const key = getDirectiveKeyFromValueId(valueId);
      update[`flags.${MODULE_ID}.primaryDirectiveKey`] = key ? key : null;

      // Keep directiveLabels updated from the directives list (or existing map).
      // Do not allow editing directive text from this Primary Value UI.
      if (key) {
        try {
          const existing = log.getFlag?.(MODULE_ID, "directiveLabels") ?? {};
          const cloned = isPlainObject(existing)
            ? foundry.utils.deepClone(existing)
            : {};

          const fromList = directivesByKey.get(String(key)) ?? "";
          const fromExisting =
            typeof cloned?.[String(key)] === "string"
              ? String(cloned[String(key)])
              : "";
          const desired = sanitizeDirectiveText(fromList || fromExisting);

          if (desired && String(cloned[String(key)] ?? "") !== desired) {
            cloned[String(key)] = desired;
            update[`flags.${MODULE_ID}.directiveLabels`] = cloned;
          }
        } catch (_) {
          // ignore
        }
      }
    } else {
      update[`flags.${MODULE_ID}.primaryDirectiveKey`] = null;
    }

    // Calls-back-to link
    // Preserve existing milestoneId when updating callbackLink
    const existingCallbackLink =
      log.getFlag?.(MODULE_ID, "callbackLink") ?? null;
    const existingMilestoneId = isPlainObject(existingCallbackLink)
      ? existingCallbackLink.milestoneId
      : undefined;

    if (!fromLogId) {
      // When clearing the callback link, preserve milestoneId if it exists
      // but explicitly clear fromLogId and valueId to avoid stale references
      if (existingMilestoneId) {
        update[`flags.${MODULE_ID}.callbackLink`] = {
          milestoneId: existingMilestoneId,
          fromLogId: null,
          valueId: null,
        };
      } else {
        update[`flags.${MODULE_ID}.callbackLink`] = null;
      }
      update[`flags.${MODULE_ID}.callbackLinkDisabled`] = true;
    } else {
      update[`flags.${MODULE_ID}.callbackLinkDisabled`] = null;
      const newCallbackLink = {
        fromLogId: String(fromLogId),
        valueId: String(valueId),
      };
      if (existingMilestoneId) {
        newCallbackLink.milestoneId = existingMilestoneId;
      }
      update[`flags.${MODULE_ID}.callbackLink`] = newCallbackLink;
    }

    // Arc info
    if (!wantsArcEnd) {
      update[`flags.${MODULE_ID}.arcInfo`] = null;
    } else {
      // Preserve existing arc title. The title is edited via the Arc title-bar
      // edit button (character sheet), so don't overwrite it from the Log sheet.
      let arcLabel = "";
      try {
        const curArcInfo = log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
        arcLabel = String(curArcInfo?.arcLabel ?? "");
      } catch (_) {
        arcLabel = "";
      }

      // If no title exists yet (new arc end), default to the current Value name.
      // This is persisted once and won't change if the Value is renamed later.
      if (!arcLabel.trim() && arcValueId) {
        try {
          if (isDirectiveValueId(arcValueId)) {
            const name = getDirectiveTextForValueId(log, arcValueId);
            if (name) arcLabel = name;
          } else {
            const v = actor.items.get(String(arcValueId));
            const name = v?.type === "value" ? String(v.name ?? "") : "";
            if (name) arcLabel = name;
          }
        } catch (_) {
          // ignore
        }
      }

      const arcInfo = {
        isArc: true,
        steps,
        valueId: String(arcValueId),
      };
      arcInfo.arcLabel = String(arcLabel ?? "");
      update[`flags.${MODULE_ID}.arcInfo`] = arcInfo;
    }

    // Sync icon to Primary Value (or default)
    try {
      const desiredImg =
        valueId && isDirectiveValueId(valueId)
          ? directiveIconPath()
          : (() => {
              const valueItem = valueId ? actor.items.get(valueId) : null;
              return valueItem?.type === "value" && valueItem?.img
                ? String(valueItem.img)
                : getStaDefaultIcon?.() || STA_DEFAULT_ICON;
            })();
      if (desiredImg && String(log.img ?? "") !== String(desiredImg)) {
        update.img = desiredImg;
      }
    } catch (_) {
      // ignore
    }

    try {
      await log.update(update, { render: false, renderSheet: false });

      // If the callback target changed, ensure the source log has an invoked
      // value state that matches the target's chain value.
      const fromLogChanged =
        fromLogId && String(fromLogId) !== String(_baselineFromLogId);

      // Update baseline to the newly-saved state.
      _baselineFromLogId = String(fromLogId);
      _baselineValueId = String(valueId);
      _baselineIsArcEnd = Boolean(wantsArcEnd);
      _baselineArcSteps = steps;
      _baselineArcValueId = String(arcValueId || valueId || "");

      if (fromLogChanged) {
        await _ensureSourceHasMatchingValueState(actor, log, fromLogId);
      }

      // Ensure character sheets refresh their log sorting/indentation.
      try {
        refreshMissionLogSortingForActorId(actor.id);
      } catch (_) {
        // ignore
      }
    } catch (err) {
      console.warn(`${MODULE_ID} | failed saving log link controls`, err);
      ui.notifications?.error?.("Failed to save log link data.");
    } finally {
      _saveInFlight = false;
    }
  };

  fromSelect.addEventListener("change", (ev) => {
    try {
      ev?.stopPropagation?.();
    } catch (_) {
      // ignore
    }
    alignPrimaryValueToCallbackTarget();
    syncFormFields();
    scheduleSave();
  });

  valueSelect.addEventListener("change", (ev) => {
    try {
      ev?.stopPropagation?.();
    } catch (_) {
      // ignore
    }
    refreshFromOptions();
    syncFormFields();
    scheduleSave();
  });

  arcToggle.addEventListener("change", (ev) => {
    try {
      ev?.stopPropagation?.();
    } catch (_) {
      // ignore
    }
    syncFormFields();
    scheduleSave();
  });

  arcStepsInput.addEventListener("change", (ev) => {
    try {
      ev?.stopPropagation?.();
    } catch (_) {
      // ignore
    }
    syncFormFields();
    scheduleSave();
  });

  // Milestone select change handler - saves directly to the callbackLink flag
  milestoneSelect.addEventListener("change", async (ev) => {
    try {
      ev?.stopPropagation?.();
      ev?.preventDefault?.();
    } catch (_) {
      // ignore
    }

    const selectedMilestoneId = String(milestoneSelect.value ?? "");
    try {
      const current = log.getFlag?.(MODULE_ID, "callbackLink") ?? null;
      const next = {
        ...(isPlainObject(current) ? current : {}),
      };

      if (selectedMilestoneId) next.milestoneId = selectedMilestoneId;
      else delete next.milestoneId;

      await log.update(
        { [`flags.${MODULE_ID}.callbackLink`]: next },
        { render: false, renderSheet: false },
      );
    } catch (_) {
      // flag update failed, possibly permissions
    }
  });

  // Ensure the fromLog options reflect the current primary value on initial render.
  refreshFromOptions();

  // --- Add Directive button (inline in the system value-state table header) ---
  const installAddDirectiveButton = () => {
    const anyStateInput =
      sheetRoot.querySelector(
        'input[type="checkbox"][name^="system.valueStates."][data-action="onSelectValue"]',
      ) ||
      sheetRoot.querySelector(
        'input[type="checkbox"][name^="system.valueStates."]',
      ) ||
      sheetRoot.querySelector('input[name^="system.valueStates."]');

    const firstRow = anyStateInput?.closest?.(".row") ?? null;
    const rowsParent = firstRow?.parentElement ?? null;
    if (!rowsParent) return;

    const headerRow =
      rowsParent.querySelector(":scope > .row.title") ||
      rowsParent.querySelector(".row.title");
    if (!(headerRow instanceof HTMLElement)) return;

    const nameCol =
      headerRow.querySelector(":scope > .col-name") ||
      headerRow.querySelector(".col-name");
    if (!(nameCol instanceof HTMLElement)) return;

    if (nameCol.querySelector(":scope > .sta-add-directive-btn")) return;

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "sta-inline-sheet-btn sta-add-directive-btn";
    btn.textContent = "Add Directive";

    btn.addEventListener("click", async (ev) => {
      try {
        ev?.preventDefault?.();
        ev?.stopPropagation?.();
      } catch (_) {
        // ignore
      }

      const optionsHtml = Array.from(directivesByKey.entries())
        .map(([key, text]) => {
          return `<option value="${escapeHTML(String(key))}">${escapeHTML(
            String(text),
          )}</option>`;
        })
        .join("");

      const res = await foundry.applications.api.DialogV2.wait({
        window: { title: "Add Directive" },
        content: `
          <div class="form-group">
            <label>Directive</label>
            <div class="form-fields">
              <select name="directiveKey">
                <option value="__other__">${escapeHTML(
                  t("sta-officers-log.dialog.useDirective.other"),
                )}</option>
                ${optionsHtml}
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Text (optional)</label>
            <div class="form-fields">
              <input type="text" name="directiveText" maxlength="100" placeholder="${escapeHTML(
                t("sta-officers-log.dialog.useDirective.otherPlaceholder"),
              )}" />
            </div>
            <p class="hint">If blank, uses the selected directive. Sanitized, max 100 characters.</p>
          </div>
        `,
        buttons: [
          {
            action: "add",
            label: "Add",
            default: true,
            callback: (_event, button) => ({
              directiveKey: String(
                button.form?.elements?.directiveKey?.value ?? "__other__",
              ),
              directiveText: String(
                button.form?.elements?.directiveText?.value ?? "",
              ),
            }),
          },
          { action: "cancel", label: "Cancel" },
        ],
        rejectClose: false,
        modal: false,
      });

      if (!res || res === "cancel") return;

      const selectedKey = String(res.directiveKey ?? "__other__");
      const typed = sanitizeDirectiveText(res.directiveText ?? "");
      const chosen = typed
        ? typed
        : selectedKey && selectedKey !== "__other__"
          ? directivesByKey.get(selectedKey) || ""
          : "";
      const cleaned = sanitizeDirectiveText(chosen);
      if (!cleaned) {
        ui.notifications?.warn?.(
          t("sta-officers-log.dialog.useDirective.missing"),
        );
        return;
      }

      const valueId = makeDirectiveValueIdFromText(cleaned);
      const key = makeDirectiveKeyFromText(cleaned);
      if (!valueId || !key) return;

      const curStates = getValueStateArray(log, valueId);
      const hasInvoked = curStates.some((s) => isValueInvokedState(String(s)));
      const nextState = hasInvoked ? null : "positive";

      const update = {};
      if (nextState) {
        const existingRaw = log?.system?.valueStates?.[String(valueId)];
        update[`system.valueStates.${valueId}`] = mergeValueStateArray(
          existingRaw,
          nextState,
        );
      }

      try {
        const existing = log.getFlag?.(MODULE_ID, "directiveLabels") ?? {};
        const cloned = isPlainObject(existing)
          ? foundry.utils.deepClone(existing)
          : {};
        cloned[String(key)] = cleaned;
        update[`flags.${MODULE_ID}.directiveLabels`] = cloned;
      } catch (_) {
        // ignore
      }

      try {
        await log.update(update, { render: false, renderSheet: false });
      } catch (_) {
        // ignore
      }

      try {
        refreshMissionLogSortingForActorId(actor.id);
      } catch (_) {
        // ignore
      }

      try {
        log?.sheet?.render?.(false);
      } catch (_) {
        // ignore
      }
    });

    nameCol.appendChild(btn);
  };

  // Ensure the currently-selected directive is present in the Primary Value dropdown.
  if (selectedValueId && isDirectiveValueId(selectedValueId)) {
    ensurePrimaryValueOptionExists(
      String(selectedValueId),
      getDirectiveTextForValueId(log, selectedValueId),
    );
  }

  // --- Inline invoked directives in the value state list ---

  const installInlineInvokedDirectiveRows = () => {
    const invoked = [];
    const states = log?.system?.valueStates ?? {};
    for (const valueId of Object.keys(states)) {
      if (!isDirectiveValueId(valueId)) continue;

      const stateArr = getValueStateArray(log, valueId);
      const invokedState = stateArr.find((s) => isValueInvokedState(String(s)));
      if (!invokedState) continue;

      const stateSet = new Set(stateArr.map((s) => String(s)));
      invoked.push({
        valueId: String(valueId),
        state: String(invokedState),
        stateSet,
        text: getDirectiveTextForValueId(log, valueId),
      });
    }
    invoked.sort((a, b) =>
      String(a.text ?? a.valueId).localeCompare(
        String(b.text ?? b.valueId),
        undefined,
        {
          sensitivity: "base",
        },
      ),
    );

    // Find the system-provided value-state rows.
    const anySystemStateInput =
      sheetRoot.querySelector(
        'input[type="checkbox"][name^="system.valueStates."][data-action="onSelectValue"]',
      ) ||
      sheetRoot.querySelector(
        'input[type="checkbox"][name^="system.valueStates."]',
      ) ||
      sheetRoot.querySelector('input[name^="system.valueStates."]');

    const firstRow = anySystemStateInput?.closest?.(".row") ?? null;
    const rowsParent = firstRow?.parentElement ?? null;
    if (!rowsParent) return;

    // Clear any previously injected directive rows.
    for (const el of Array.from(
      rowsParent.querySelectorAll(":scope > .sta-directive-value-row"),
    )) {
      try {
        el.remove();
      } catch (_) {
        // ignore
      }
    }

    if (!invoked.length) return;

    const valueStateRows = Array.from(rowsParent.children).filter((el) => {
      if (!(el instanceof HTMLElement)) return false;
      if (!el.classList.contains("row")) return false;
      if (el.classList.contains("sta-directive-value-row")) return false;
      return Boolean(
        el.querySelector(
          'input[type="checkbox"][name^="system.valueStates."]',
        ) || el.querySelector('input[name^="system.valueStates."]'),
      );
    });

    const insertAfter = valueStateRows.length
      ? valueStateRows[valueStateRows.length - 1]
      : firstRow;
    if (!(insertAfter instanceof HTMLElement)) return;

    let anchor = insertAfter;

    for (const d of invoked) {
      const row = document.createElement("div");
      row.className = "row sta-directive-value-row";
      row.dataset.staDirectiveValueId = d.valueId;

      const safeText = sanitizeDirectiveText(d.text ?? "") || d.valueId;

      const nameCol = document.createElement("div");
      nameCol.className = "col-name value-name sta-directive-name-cell";

      const textInput = document.createElement("input");
      textInput.type = "text";
      textInput.className = "text-entry sta-directive-inline-text";
      textInput.value = safeText;
      textInput.placeholder = t(
        "sta-officers-log.dialog.useDirective.otherPlaceholder",
      );
      textInput.maxLength = 100;
      textInput.readOnly = true;
      nameCol.appendChild(textInput);

      const editBtn = document.createElement("button");
      editBtn.type = "button";
      editBtn.className = "sta-directive-edit-btn";
      editBtn.title = "Edit directive";
      editBtn.setAttribute("aria-label", "Edit directive");
      editBtn.innerHTML = '<i class="fa-solid fa-pen"></i>';
      nameCol.appendChild(editBtn);

      const removeBtn = document.createElement("button");
      removeBtn.type = "button";
      removeBtn.className = "sta-directive-remove-btn";
      removeBtn.title = "Remove directive";
      removeBtn.setAttribute("aria-label", "Remove directive");
      removeBtn.innerHTML = '<i class="fa-solid fa-trash"></i>';
      nameCol.appendChild(removeBtn);

      row.appendChild(nameCol);

      const buildCheckbox = (value) => {
        const col = document.createElement("div");
        col.className = "col-radio";

        const label = document.createElement("label");
        const input = document.createElement("input");
        input.type = "checkbox";
        input.name = `system.valueStates.${d.valueId}`;
        input.value = value;

        const set = d.stateSet instanceof Set ? d.stateSet : new Set();
        if (set.has(String(value))) input.checked = true;

        label.appendChild(input);
        col.appendChild(label);

        return { input, col };
      };

      const unused = buildCheckbox("unused");
      const pos = buildCheckbox("positive");
      const neg = buildCheckbox("negative");
      const chal = buildCheckbox("challenged");

      const allInputs = [unused.input, pos.input, neg.input, chal.input];

      row.appendChild(unused.col);
      row.appendChild(pos.col);
      row.appendChild(neg.col);
      row.appendChild(chal.col);

      const onStateChange = async (ev) => {
        const input = ev?.currentTarget;
        if (!(input instanceof HTMLInputElement)) return;

        const checked = allInputs
          .filter((i) => i instanceof HTMLInputElement && i.checked)
          .map((i) => String(i.value ?? ""))
          .filter(Boolean);

        let payload = Array.from(new Set(checked));
        if (!payload.length) payload = ["unused"];

        // If any invoked state is present, drop "unused".
        if (payload.some((v) => v !== "unused")) {
          payload = payload.filter((v) => v !== "unused");
          if (!payload.length) payload = ["unused"];
        }

        try {
          await log.update(
            { [`system.valueStates.${d.valueId}`]: payload },
            { render: false, renderSheet: false },
          );
        } catch (_) {
          // ignore
        }

        if (payload.length === 1 && payload[0] === "unused") {
          try {
            row.remove();
          } catch (_) {
            // ignore
          }
        }

        try {
          refreshMissionLogSortingForActorId(actor.id);
        } catch (_) {
          // ignore
        }
      };

      for (const r of allInputs) {
        r.addEventListener("change", (ev) => {
          try {
            ev?.stopPropagation?.();
          } catch (_) {
            // ignore
          }
          void onStateChange(ev);
        });
      }

      const onTextChange = async () => {
        const newText = sanitizeDirectiveText(textInput.value ?? "");
        if (!newText) {
          textInput.value = safeText;
          return;
        }

        const oldId = String(d.valueId);
        const newId = makeDirectiveValueIdFromText(newText);
        if (!newId) return;

        const oldStates = getValueStateArray(log, oldId);
        const invoked = oldStates.filter((s) => isValueInvokedState(String(s)));
        const oldState = invoked.length ? String(invoked[0]) : "unused";
        if (oldState === "unused") return;

        const oldKey = getDirectiveKeyFromValueId(oldId);
        const newKey = makeDirectiveKeyFromText(newText);

        const update = {};

        if (newId !== oldId) {
          update[`system.valueStates.${oldId}`] = ["unused"];
          update[`system.valueStates.${newId}`] = [oldState];

          try {
            const curPrimary = String(
              log.getFlag?.(MODULE_ID, "primaryValueId") ?? "",
            );
            if (curPrimary === oldId)
              update[`flags.${MODULE_ID}.primaryValueId`] = newId;
          } catch (_) {
            // ignore
          }

          try {
            const link = log.getFlag?.(MODULE_ID, "callbackLink") ?? null;
            const linkVal = String(link?.valueId ?? "");
            if (linkVal === oldId) {
              update[`flags.${MODULE_ID}.callbackLink.valueId`] = newId;
            }
          } catch (_) {
            // ignore
          }

          try {
            const arcInfo = log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
            const arcVal = String(arcInfo?.valueId ?? "");
            if (arcVal === oldId) {
              update[`flags.${MODULE_ID}.arcInfo.valueId`] = newId;
            }
          } catch (_) {
            // ignore
          }
        }

        try {
          const existingLabels =
            log.getFlag?.(MODULE_ID, "directiveLabels") ?? {};
          const cloned = isPlainObject(existingLabels)
            ? foundry.utils.deepClone(existingLabels)
            : {};
          if (oldKey) delete cloned[String(oldKey)];
          if (newKey) cloned[String(newKey)] = newText;
          update[`flags.${MODULE_ID}.directiveLabels`] = cloned;
        } catch (_) {
          // ignore
        }

        try {
          await log.update(update, { render: false, renderSheet: false });
        } catch (_) {
          // ignore
        }

        try {
          refreshMissionLogSortingForActorId(actor.id);
        } catch (_) {
          // ignore
        }

        // Re-render to rebuild the inline rows with the new id.
        try {
          log?.sheet?.render?.(false);
        } catch (_) {
          // ignore
        }
      };

      textInput.addEventListener("change", (ev) => {
        try {
          ev?.stopPropagation?.();
        } catch (_) {
          // ignore
        }
        void onTextChange();
      });

      const setEditingState = (isEditing) => {
        textInput.readOnly = !isEditing;
        row.classList.toggle("sta-directive-editing", isEditing);
        if (isEditing) {
          editBtn.innerHTML = '<i class="fa-solid fa-floppy-disk"></i>';
          editBtn.title = "Save directive";
          editBtn.setAttribute("aria-label", "Save directive");
        } else {
          editBtn.innerHTML = '<i class="fa-solid fa-pen"></i>';
          editBtn.title = "Edit directive";
          editBtn.setAttribute("aria-label", "Edit directive");
        }
      };

      let pendingSaveClick = false;

      editBtn.addEventListener("pointerdown", () => {
        if (!textInput.readOnly) pendingSaveClick = true;
      });

      editBtn.addEventListener("click", (ev) => {
        try {
          ev?.preventDefault?.();
          ev?.stopPropagation?.();
        } catch (_) {
          // ignore
        }

        if (pendingSaveClick) {
          pendingSaveClick = false;
          if (!textInput.readOnly) setEditingState(false);
          return;
        }

        if (textInput.readOnly) {
          setEditingState(true);
          try {
            textInput.focus();
            textInput.select?.();
          } catch (_) {
            // ignore
          }
        } else {
          setEditingState(false);
          try {
            textInput.blur();
          } catch (_) {
            // ignore
          }
        }
      });

      textInput.addEventListener("blur", () => {
        if (!textInput.readOnly) setEditingState(false);
      });

      removeBtn.addEventListener("click", async (ev) => {
        try {
          ev?.preventDefault?.();
          ev?.stopPropagation?.();
        } catch (_) {
          // ignore
        }

        const oldId = String(d.valueId);
        const oldKey = getDirectiveKeyFromValueId(oldId);

        const update = {
          [`system.valueStates.${oldId}`]: ["unused"],
        };

        // If this directive is referenced by log metadata, clear it.
        try {
          const curPrimary = String(
            log.getFlag?.(MODULE_ID, "primaryValueId") ?? "",
          );
          if (curPrimary === oldId) {
            update[`flags.${MODULE_ID}.primaryValueId`] = null;
            update[`flags.${MODULE_ID}.primaryDirectiveKey`] = null;

            // Clear callback link (cannot keep a link without a valueId).
            update[`flags.${MODULE_ID}.callbackLink`] = null;
            update[`flags.${MODULE_ID}.callbackLinkDisabled`] = true;

            // Clear arc info if it depended on this directive.
            update[`flags.${MODULE_ID}.arcInfo`] = null;

            // Restore default icon.
            update.img = getStaDefaultIcon?.() || STA_DEFAULT_ICON;
          }
        } catch (_) {
          // ignore
        }

        try {
          const link = log.getFlag?.(MODULE_ID, "callbackLink") ?? null;
          const linkVal = String(link?.valueId ?? "");
          if (linkVal === oldId) {
            update[`flags.${MODULE_ID}.callbackLink`] = null;
            update[`flags.${MODULE_ID}.callbackLinkDisabled`] = true;
          }
        } catch (_) {
          // ignore
        }

        try {
          const arcInfo = log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
          const arcVal = String(arcInfo?.valueId ?? "");
          if (arcVal === oldId) {
            update[`flags.${MODULE_ID}.arcInfo`] = null;
          }
        } catch (_) {
          // ignore
        }

        // Remove from directiveLabels map so it is no longer considered invoked/displayed.
        try {
          if (oldKey) {
            const existingLabels =
              log.getFlag?.(MODULE_ID, "directiveLabels") ?? {};
            const cloned = isPlainObject(existingLabels)
              ? foundry.utils.deepClone(existingLabels)
              : {};
            if (String(oldKey) in cloned) {
              delete cloned[String(oldKey)];
              update[`flags.${MODULE_ID}.directiveLabels`] = cloned;
            }
          }
        } catch (_) {
          // ignore
        }

        try {
          await log.update(update, { render: false, renderSheet: false });
        } catch (_) {
          // ignore
        }

        try {
          row.remove();
        } catch (_) {
          // ignore
        }

        try {
          refreshMissionLogSortingForActorId(actor.id);
        } catch (_) {
          // ignore
        }

        try {
          log?.sheet?.render?.(false);
        } catch (_) {
          // ignore
        }
      });

      anchor.after(row);
      anchor = row;
    }
  };

  installInlineInvokedDirectiveRows();
  installAddDirectiveButton();

  // On open: if we already have a callback target selected, align Primary Value
  // to match that target (legacy data normalization). Only auto-save if this
  // alignment actually changes the Primary Value.
  const _openFromLogId = String(fromSelect.value ?? "");
  const _openValueId = String(valueSelect.value ?? "");
  const _hasPersistedPrimary = Boolean(String(persistedPrimary ?? "").trim());
  if (!_hasPersistedPrimary && _openFromLogId) {
    alignPrimaryValueToCallbackTarget();
  }

  // Ensure hidden fields are initialized to match current UI.
  syncFormFields();

  if (
    !_hasPersistedPrimary &&
    _openFromLogId &&
    String(valueSelect.value ?? "") !== _openValueId
  ) {
    scheduleSave();
  }

  // No auto-save on open (except legacy normalization above).
}
