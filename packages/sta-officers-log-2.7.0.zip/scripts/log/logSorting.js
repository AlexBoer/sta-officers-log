import { MODULE_ID } from "../core/constants.js";
import {
  getCompletedArcEndLogIds,
  getPrimaryValueIdForLog,
} from "./logMetadata.js";
import { NO_VALUE_USED_ID, isNoValueUsedId } from "../directives/directives.js";
import { getValueStateArray, isValueInvokedState } from "../values/values.js";
import { t } from "../core/i18n.js";
import { openNewMilestoneArcDialog } from "../milestones/newMilestoneArcDialog.js";

export { getCompletedArcEndLogIds, getPrimaryValueIdForLog };

// Collapsed-arc state stored in localStorage (per user, per actor).
// An in-memory cache avoids repeated JSON.parse calls within a single render cycle.
const _collapsedArcsByActorId = new Map(); // actorId -> Set<arcId>

const _FLAG_KEY = "collapsedArcIds";

function _lsKey(actor, key) {
  return `${MODULE_ID}:${actor?.id ?? ""}:${game?.user?.id ?? ""}:${key}`;
}

/**
 * Hydrate the in-memory cache from localStorage.
 * Only runs once per actor per page-load; subsequent calls are no-ops since
 * every write goes through _persistToStorage which keeps both in sync.
 * Falls back to the actor flag once for migration of pre-existing data.
 */
function _hydrateFromActor(actor) {
  if (!actor?.id) return;
  const aId = String(actor.id);
  if (_collapsedArcsByActorId.has(aId)) return; // already hydrated this session
  try {
    const raw = localStorage.getItem(_lsKey(actor, _FLAG_KEY));
    if (raw !== null) {
      const arr = JSON.parse(raw);
      _collapsedArcsByActorId.set(aId, new Set(Array.isArray(arr) ? arr : []));
      return;
    }
  } catch (_) {}
  // Migration: seed from actor flag on first read; localStorage takes over going forward.
  const arr = actor.getFlag?.(MODULE_ID, _FLAG_KEY) ?? [];
  _collapsedArcsByActorId.set(aId, new Set(Array.isArray(arr) ? arr : []));
}

/**
 * Persist the in-memory collapsed set to localStorage.
 */
function _persistToStorage(actor) {
  if (!actor?.id) return;
  const aId = String(actor.id);
  const set = _collapsedArcsByActorId.get(aId);
  const arr = set?.size ? [...set] : [];
  try {
    localStorage.setItem(_lsKey(actor, _FLAG_KEY), JSON.stringify(arr));
  } catch (_) {}
}

function _isArcCollapsed(actorId, arcId) {
  const aId = actorId ? String(actorId) : "";
  const gId = arcId ? String(arcId) : "";
  if (!aId || !gId) return false;
  const set = _collapsedArcsByActorId.get(aId);
  return set ? set.has(gId) : false;
}

function _setArcCollapsed(actorId, arcId, collapsed, actor) {
  const aId = actorId ? String(actorId) : "";
  const gId = arcId ? String(arcId) : "";
  if (!aId || !gId) return;
  let set = _collapsedArcsByActorId.get(aId);
  if (!set) {
    set = new Set();
    _collapsedArcsByActorId.set(aId, set);
  }
  if (collapsed) set.add(gId);
  else set.delete(gId);
  if (actor) _persistToStorage(actor);
}

/** @deprecated No-op: arc collapse state is now stored in localStorage per user. */
export function invalidateArcCollapseCache(_actorId) {}

function _unwrapArcGroups(containerEl) {
  const container = containerEl;
  if (!container?.querySelectorAll) return;
  const wrappers = Array.from(
    container.querySelectorAll(":scope > .sta-callbacks-arc-group"),
  );
  for (const wrapper of wrappers) {
    try {
      while (wrapper.firstChild) {
        const child = wrapper.firstChild;
        // Arc title rows are UI-only; discard them when unwrapping.
        if (child?.classList?.contains?.("sta-callbacks-arc-title")) {
          child.remove();
          continue;
        }
        container.insertBefore(child, wrapper);
      }
      wrapper.remove();
    } catch (_) {
      // DOM node may have been removed already
    }
  }
}

export function getLogSortKey(item) {
  const n = Number(item?.sort);
  return Number.isFinite(n) ? n : Number.MAX_SAFE_INTEGER;
}

export function normalizeMissionLogSortMode(mode) {
  // Backward-compatibility: previous versions stored "creation".
  const s = mode ? String(mode) : "created";
  const normalized = s === "creation" ? "created" : s;
  return ["created", "alpha", "chain", "custom"].includes(normalized)
    ? normalized
    : "created";
}

export function getMissionLogSortModeForActor(actor) {
  try {
    const stored = localStorage.getItem(_lsKey(actor, "missionLogSortMode"));
    if (stored !== null) return normalizeMissionLogSortMode(stored);
  } catch (_) {}
  // Migration: fall back to actor flag on first read.
  return normalizeMissionLogSortMode(
    actor?.getFlag?.(MODULE_ID, "missionLogSortMode"),
  );
}

export function setMissionLogSortModeForActor(actor, mode) {
  const normalized = normalizeMissionLogSortMode(mode);
  try {
    localStorage.setItem(_lsKey(actor, "missionLogSortMode"), normalized);
    return { ok: true, mode: normalized };
  } catch (err) {
    console.warn(`${MODULE_ID} | failed to persist missionLogSortMode`, err);
    return { ok: false, mode: normalized };
  }
}

/**
 * Builds the common validation context for callback links.
 */
function _buildCallbackLinkContext(actor, logItems) {
  const byId = new Map(logItems.map((l) => [String(l.id), l]));
  const completedArcEndLogIds = getCompletedArcEndLogIds(actor, byId);
  const valueItems = actor.items.filter((i) => i?.type === "value");

  const callbackLinkDisabledToLogIds = new Set();
  for (const log of logItems) {
    const disabled =
      log.system?.callbackLinkDisabled === true ||
      log.getFlag?.(MODULE_ID, "callbackLinkDisabled") === true;
    if (disabled) callbackLinkDisabledToLogIds.add(String(log.id));
  }

  return {
    byId,
    completedArcEndLogIds,
    valueItems,
    callbackLinkDisabledToLogIds,
  };
}

/**
 * Checks if a callback link from one log to a parent is valid.
 * Returns true if the link should be included in chain operations.
 */
function _isValidCallbackLink(log, parentLog, link, context) {
  if (!context) return false;

  const {
    byId,
    completedArcEndLogIds,
    valueItems,
    callbackLinkDisabledToLogIds,
  } = context;
  const logId = String(log.id);
  const parentId = link?.fromLogId ? String(link.fromLogId) : "";

  if (!parentId) return false;
  if (!byId.has(parentId)) return false;

  // Respect explicit manual unlink overrides.
  if (callbackLinkDisabledToLogIds.has(logId)) return false;

  // Break chains across completed Arc boundaries.
  if (completedArcEndLogIds.has(parentId)) return false;

  // Break chains when the source log doesn't share an invoked value with the
  // parent's chain value.  We no longer compare against the source log's own
  // primaryValueId — that may have been set for display purposes and shouldn't
  // break chain indentation.  Instead we check the parent (target) log's
  // primary; the source must have an invoked state for the same value.
  const parentPrimary = parentLog
    ? getPrimaryValueIdForLog(
        parentLog.actor || parentLog.parent,
        parentLog,
        valueItems,
      )
    : "";

  if (parentPrimary) {
    // Parent has a known chain value — source must have an invoked state for it.
    const srcStates = getValueStateArray(log, parentPrimary);
    if (!srcStates.some(isValueInvokedState)) return false;
  } else {
    // Parent has no primary — check that source shares at least one invoked
    // value with the parent's own invoked values.
    const parentInvokedIds = new Set();
    for (const v of valueItems) {
      const pStates = getValueStateArray(parentLog, v.id);
      if (pStates.some(isValueInvokedState)) parentInvokedIds.add(String(v.id));
    }
    if (parentInvokedIds.size > 0) {
      let hasOverlap = false;
      for (const vid of parentInvokedIds) {
        const srcStates = getValueStateArray(log, vid);
        if (srcStates.some(isValueInvokedState)) {
          hasOverlap = true;
          break;
        }
      }
      if (!hasOverlap) return false;
    }
  }

  return true;
}

function _getLogChainComponents(actor, logItems) {
  const context = _buildCallbackLinkContext(actor, logItems);
  const { byId } = context;
  const adj = new Map();

  const ensure = (id) => {
    const key = String(id);
    if (!adj.has(key)) adj.set(key, new Set());
    return adj.get(key);
  };

  // Undirected edges between logs that are linked via callbackLink.
  for (const log of logItems) {
    const link =
      log.system?.callbackLink ?? log.getFlag?.(MODULE_ID, "callbackLink");
    const parentLog = byId.get(link?.fromLogId);

    if (!_isValidCallbackLink(log, parentLog, link, context)) continue;

    const a = String(log.id);
    const b = String(link.fromLogId);
    ensure(a).add(b);
    ensure(b).add(a);
  }

  const visited = new Set();
  const components = [];

  for (const log of logItems) {
    const start = String(log.id);
    if (visited.has(start)) continue;

    const queue = [start];
    visited.add(start);
    const ids = [];

    while (queue.length) {
      const id = queue.pop();
      ids.push(id);
      for (const nb of adj.get(id) ?? []) {
        if (visited.has(nb)) continue;
        visited.add(nb);
        queue.push(nb);
      }
    }

    const items = ids.map((id) => byId.get(id)).filter(Boolean);
    components.push(items);
  }

  return components;
}

function _getValidCallbackParentMap(actor, logItems) {
  const context = _buildCallbackLinkContext(actor, logItems);
  const parentByChildId = new Map();

  for (const log of logItems) {
    const link =
      log.system?.callbackLink ?? log.getFlag?.(MODULE_ID, "callbackLink");
    const parentLog = context.byId.get(link?.fromLogId);

    if (!_isValidCallbackLink(log, parentLog, link, context)) continue;

    const childId = String(log.id);
    const parentId = String(link.fromLogId);
    parentByChildId.set(childId, parentId);
  }

  return parentByChildId;
}

function _getChainIndentChildLogIds(actor, logItems) {
  return new Set(_getValidCallbackParentMap(actor, logItems).keys());
}

export function applyMissionLogSorting(root, actor, mode) {
  const sortMode = normalizeMissionLogSortMode(mode);

  const section =
    root?.querySelector?.("div.section.character-log") ??
    root?.querySelector?.("div.section.milestones");
  if (!section) return;

  // ----- Milestones UI tweak: replace default "+"" with custom button -----
  try {
    // Detect whether a sta-utils alternate sheet theme (LCARS, compact, or
    // tidy) is active — if so, the header row is hidden and the create button
    // should live inside the .title element instead.
    // We check game.settings for compact / tidy because Officers Log's hook
    // fires before sta-utils adds its CSS classes to the DOM, so the DOM
    // class check alone would miss them.  LCARS is already on the DOM by
    // the time we run, so a CSS check is fine for it.
    let isAltSheet =
      root?.closest?.(
        ".sta-lcars, .sta-compact, .sta-tidy, .character-sheet--mobile",
      ) != null;
    if (!isAltSheet) {
      try {
        const staUtilsActive =
          game.modules?.get?.("sta-utils")?.active ?? false;
        if (staUtilsActive) {
          // Legacy boolean settings (pre-migration to sheetVariant)
          isAltSheet =
            game.settings.get("sta-utils", "compactCharacterSheet") === true ||
            game.settings.get("sta-utils", "tidyCharacterSheet") === true;

          // Unified sheetVariant setting (compact/tidy/lcars post-migration)
          if (!isAltSheet) {
            try {
              const v = game.settings.get("sta-utils", "sheetVariant");
              isAltSheet = v === "compact" || v === "tidy" || v === "lcars";
            } catch (_) {
              // not yet registered
            }
          }

          // Mobile sheet — detected via DOM class
          if (!isAltSheet) {
            isAltSheet = !!root?.querySelector?.(".character-sheet--mobile");
          }
        }
      } catch (_) {
        // Settings not registered yet or module not present — fall through
      }
    }

    // Try multiple selectors to find the milestone create button
    // (handles different Foundry versions and structures)
    const milestoneCreate = section.querySelector(
      'a.control.create[data-type="milestone"]',
    );

    // Determine the container where the custom button should be placed.
    // In sta-utils alternate sheet modes (LCARS / compact / tidy) the
    // button should live in the Milestones / Arcs .title element.
    // In the LCARS bespoke template the create button is already inside the
    // .title bar, so buttonIsInTitle will be true regardless of isAltSheet.
    // In compact / tidy the button is still in the header row, so we walk
    // to the preceding .title sibling when isAltSheet is true.
    // In default / other modes it stays in the header row.
    const milestoneHeaderRow =
      milestoneCreate?.closest?.("div.header.row.item") ?? null;
    const milestoneTitle =
      milestoneCreate?.closest?.(".title") ??
      (milestoneHeaderRow?.previousElementSibling?.classList?.contains("title")
        ? milestoneHeaderRow.previousElementSibling
        : null);

    const buttonIsInTitle = milestoneCreate?.closest?.(".title") != null;
    const targetContainer =
      buttonIsInTitle || isAltSheet ? milestoneTitle : milestoneHeaderRow;

    if (milestoneCreate && targetContainer) {
      // Avoid duplicates across rerenders.
      const existingCustom = targetContainer.querySelector(
        ".sta-milestone-create-placeholder",
      );
      if (!existingCustom) {
        // Remove the original Foundry create control.
        try {
          milestoneCreate.remove();
        } catch (_) {
          // element might already be detached
        }

        const btn = document.createElement("a");
        btn.className = "control sta-milestone-create-placeholder";
        btn.title = "New Milestone / Arc";
        btn.setAttribute("aria-label", "New Milestone / Arc");
        btn.setAttribute("role", "button");
        btn.tabIndex = 0;
        btn.innerHTML = '<i class="fas fa-plus"></i>';

        const onClick = async (ev) => {
          ev?.preventDefault?.();
          ev?.stopPropagation?.();

          try {
            openNewMilestoneArcDialog(actor);
          } catch (_) {
            // dialog open can fail if actor became invalid
          }
        };

        btn.addEventListener("click", onClick);
        btn.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter" || ev.key === " ") onClick(ev);
        });

        targetContainer.appendChild(btn);
      }
    }
  } catch (_) {
    // non-critical UI enhancement
  }

  // Custom mode: do not reorder anything; rely on the sheet's default order
  // (which is typically based on Item.sort / manual dragging).
  if (sortMode === "custom") return;

  const activeEl =
    typeof document === "undefined" ? null : document.activeElement;
  if (
    activeEl instanceof HTMLElement &&
    activeEl.closest?.("li.row.entry[data-item-type='log']") &&
    section.contains?.(activeEl)
  ) {
    // Let the user finish typing before we reshuffle the log rows.
    return;
  }

  // STA v2.4.6+: Logs and Milestones are each inside their own
  // ".item-list-scrollable" container under the same section.
  // If present, we must reorder logs within that container (not the section root),
  // otherwise entries get moved out of their scrollable list.
  const scrollableLists = Array.from(
    section.querySelectorAll(":scope > .item-list-scrollable"),
  ).filter((el) => el instanceof HTMLElement);

  const logListScrollable =
    scrollableLists.find((el) =>
      el.querySelector('li.row.entry[data-item-type="log"]'),
    ) ?? null;

  const logContainer = logListScrollable ?? section;

  const logEntryEls = Array.from(
    logContainer.querySelectorAll('li.row.entry[data-item-type="log"]'),
  );
  if (!logEntryEls.length) return;

  // Try to locate the Log header row (used for some UI tweaks and as a
  // fallback insertion anchor in older sheet layouts).
  const topTitles = Array.from(
    section.querySelectorAll(":scope > div.title"),
  ).filter((el) => el instanceof HTMLElement);

  const logTitleEl =
    section.querySelector(":scope > div.title.sta-values-title-with-button") ??
    topTitles[0] ??
    null;

  const logHeaderEl = (() => {
    const next = logTitleEl?.nextElementSibling ?? null;
    if (next?.matches?.("div.header.row.item")) return next;
    const first = section.querySelector(":scope > div.header.row.item");
    return first?.matches?.("div.header.row.item") ? first : null;
  })();

  // Old layout (no scrollable wrapper): logs and milestones share a parent.
  // New layout: we already have a dedicated insertion parent.
  let milestoneTitleEl = null;
  let milestoneHeaderEl = null;
  let firstMilestoneEntryEl = null;

  let insertionParent = logContainer;

  if (!logListScrollable) {
    // Find the first title *after* the log header/title (this is the start of the
    // Milestones / Arcs area). We intentionally do not rely on localized text.
    const walkStart = logHeaderEl ?? logTitleEl ?? null;
    if (walkStart) {
      let node = walkStart.nextElementSibling;
      while (node) {
        if (node.matches?.("div.title") && node !== logTitleEl) {
          milestoneTitleEl = node;
          break;
        }
        node = node.nextElementSibling;
      }
    }

    milestoneHeaderEl = milestoneTitleEl
      ? milestoneTitleEl.nextElementSibling?.matches?.("div.header.row.item")
        ? milestoneTitleEl.nextElementSibling
        : null
      : null;

    firstMilestoneEntryEl = section.querySelector(
      'li.row.entry[data-item-type="milestone"]',
    );

    insertionParent =
      milestoneTitleEl?.parentElement ??
      milestoneHeaderEl?.parentElement ??
      firstMilestoneEntryEl?.parentElement ??
      logHeaderEl?.parentElement ??
      logTitleEl?.parentElement ??
      section;
  }

  // If we wrapped logs previously, unwrap them before any reordering.
  _unwrapArcGroups(insertionParent);

  const logItems = logEntryEls
    .map((el) => {
      const id = el?.dataset?.itemId ? String(el.dataset.itemId) : "";
      const item = id ? actor.items.get(id) : null;
      return item && item.type === "log" ? item : null;
    })
    .filter(Boolean);

  const byId = new Map(logItems.map((l) => [String(l.id), l]));
  const byElId = new Map(
    logEntryEls
      .map((el) => [String(el?.dataset?.itemId ?? ""), el])
      .filter(([id]) => id),
  );

  const clearIndent = () => {
    for (const el of logEntryEls)
      el.classList.remove("sta-callbacks-chain-child");
  };

  const clearArcDecorations = () => {
    for (const el of logEntryEls) {
      try {
        delete el.dataset.staCallbacksArcId;
      } catch (_) {
        // dataset property may be frozen
      }
      // Reset any display overrides from collapsed state.
      if (el.style?.display) el.style.display = "";
    }
  };

  const sortCreation = (a, b) => {
    const d = getLogSortKey(a) - getLogSortKey(b);
    if (d) return d;
    const an = String(a.name ?? "");
    const bn = String(b.name ?? "");
    const nd = an.localeCompare(bn, undefined, { sensitivity: "base" });
    if (nd) return nd;
    return String(a.id).localeCompare(String(b.id));
  };

  let orderedIds = [];
  /** @type {null | Array<{arcId:string, arcLabel:string, ids:string[]}>} */
  let arcWrapGroups = null;

  const getCreatedTimeKey = (item) => {
    // Check for custom date first (stored as YYYY-MM-DD string in flags)
    try {
      const customDate =
        item?.system?.customDate || item?.flags?.[MODULE_ID]?.customDate;
      if (customDate && typeof customDate === "string") {
        // Parse YYYY-MM-DD to timestamp (midnight UTC)
        const parsed = Date.parse(customDate + "T00:00:00Z");
        if (Number.isFinite(parsed)) {
          return parsed;
        }
      }
    } catch (_) {
      // ignore
    }

    // Fall back to actual creation time
    // Prefer the live document stats, but fall back to _source for safety.
    // (Some document instances may not expose _stats directly.)
    const direct = item?._stats?.createdTime;
    const source = item?._source?._stats?.createdTime;
    const t = Number(direct ?? source);
    return Number.isFinite(t) ? t : Number.MAX_SAFE_INTEGER;
  };

  const sortCreatedTime = (a, b) => {
    // Oldest-first by createdTime.
    const d = getCreatedTimeKey(a) - getCreatedTimeKey(b);
    if (d) return d;

    // IMPORTANT: do NOT fall back to Item.sort here.
    // Item.sort reflects manual drag order, which is exactly what "custom" is for.
    const an = String(a.name ?? "");
    const bn = String(b.name ?? "");
    const nd = an.localeCompare(bn, undefined, { sensitivity: "base" });
    if (nd) return nd;
    return String(a.id).localeCompare(String(b.id));
  };

  if (sortMode === "created") {
    clearIndent();
    clearArcDecorations();
    const items = Array.from(logItems).sort(sortCreatedTime);
    orderedIds = items.map((i) => String(i.id));
  } else if (sortMode === "alpha") {
    clearIndent();
    clearArcDecorations();
    const items = Array.from(logItems);
    items.sort((a, b) => {
      const an = String(a.name ?? "");
      const bn = String(b.name ?? "");
      const nd = an.localeCompare(bn, undefined, { sensitivity: "base" });
      if (nd) return nd;
      return sortCreation(a, b);
    });
    orderedIds = items.map((i) => String(i.id));
  } else if (sortMode === "chain") {
    clearArcDecorations();
    const valueItems = actor.items.filter((i) => i?.type === "value");

    const computeChainLogIdsByParentWalk = (
      actorDoc,
      endLogId,
      maxSteps,
      disallowNodeIds,
      presentIdSet,
    ) => {
      try {
        const steps = Number(maxSteps);
        if (!Number.isFinite(steps) || steps <= 0) return [];
        const actorItems = actorDoc?.items ?? null;
        if (!actorItems?.get) return [];

        const present = presentIdSet ?? null;
        const result = [];
        const seen = new Set();
        let cur = endLogId ? String(endLogId) : "";

        while (cur && result.length < steps) {
          const id = String(cur);
          if (seen.has(id)) break;
          seen.add(id);

          if (present && !present.has(id)) break;

          const curItem = actorItems.get(id);
          if (!curItem || curItem.type !== "log") break;

          result.push(id);

          const parentRaw =
            (
              curItem.system?.callbackLink ??
              curItem.getFlag?.(MODULE_ID, "callbackLink")
            )?.fromLogId ?? "";
          const parentId = parentRaw ? String(parentRaw) : "";
          if (!parentId) break;

          if (disallowNodeIds?.has?.(parentId)) break;

          if (present && !present.has(parentId)) break;
          const parentItem = actorItems.get(parentId);
          if (!parentItem || parentItem.type !== "log") break;

          cur = parentId;
        }

        return result.reverse();
      } catch (_) {
        // return empty on any traversal failure
        return [];
      }
    };

    const isStaleStoredChain = (
      storedChainIds,
      endLogId,
      steps,
      parentId,
      presentIdSet,
      disallowNodeIds,
    ) => {
      try {
        const s = Number(steps);
        if (!Number.isFinite(s) || s <= 1) return false;

        const endId = endLogId ? String(endLogId) : "";
        if (!endId) return false;

        const chain = (Array.isArray(storedChainIds) ? storedChainIds : [])
          .map((x) => String(x))
          .filter(Boolean);

        const pId = parentId ? String(parentId) : "";
        const hasValidParent =
          pId && presentIdSet?.has?.(pId) && !disallowNodeIds?.has?.(pId);

        // Stale case A: steps>1, but stored chain is just the end log, even though
        // a valid parent is present and allowed.
        if (chain.length === 1 && chain[0] === endId && hasValidParent)
          return true;

        // Stale case B: stored chain points at missing logs; after filtering it becomes empty,
        // but a valid parent exists so we can reconstruct.
        const presentChain = chain.filter((id) => presentIdSet?.has?.(id));
        if (chain.length > 0 && presentChain.length === 0 && hasValidParent)
          return true;

        return false;
      } catch (_) {
        // treat as not stale if check fails
        return false;
      }
    };

    // ----- 1) Build completed-Arc blocks first (Arc Order) -----
    /** @type {Array<{arcId:string, ids:string[], maxTime:number, valueNameLabel:string}>} */
    const arcBlocks = [];
    const usedArcIds = new Set();

    const arcEndLogs = logItems.filter((log) => {
      const arcInfo =
        log.system?.arcInfo ?? log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
      return arcInfo?.isArc === true;
    });

    for (const log of arcEndLogs) {
      const arcInfo =
        log.system?.arcInfo ?? log.getFlag?.(MODULE_ID, "arcInfo") ?? null;
      if (!arcInfo?.isArc) continue;

      const arcValueId = arcInfo?.valueId
        ? String(arcInfo.valueId)
        : getPrimaryValueIdForLog(actor, log, valueItems);

      let steps = Number(arcInfo?.steps ?? 0);
      if (!Number.isFinite(steps) || steps <= 0) {
        const fromChain = Array.isArray(arcInfo?.chainLogIds)
          ? arcInfo.chainLogIds.length
          : 0;
        steps = fromChain > 0 ? fromChain : 1;
      }

      /** @type {string[]} */
      let chainIds = [];

      try {
        // Disallow reusing nodes already consumed by OTHER arcs.
        const disallowNodeIds = new Set();
        for (const other of logItems) {
          if (String(other.id) === String(log.id)) continue;
          const otherArcInfo = other.getFlag?.(MODULE_ID, "arcInfo") ?? null;
          if (otherArcInfo?.isArc !== true) continue;
          const otherChain = Array.isArray(otherArcInfo.chainLogIds)
            ? otherArcInfo.chainLogIds
            : [];
          for (const id of otherChain) {
            if (id) disallowNodeIds.add(String(id));
          }
        }

        // Prefer stored chain list (source of truth).
        chainIds = Array.isArray(arcInfo.chainLogIds)
          ? arcInfo.chainLogIds.map((x) => String(x)).filter(Boolean)
          : [];

        // If the stored chain is obviously stale, force fallback parent-walk.
        const parentIdRaw = (
          log.system?.callbackLink ?? log.getFlag?.(MODULE_ID, "callbackLink")
        )?.fromLogId;
        const parentId = parentIdRaw ? String(parentIdRaw) : "";
        if (
          chainIds.length &&
          isStaleStoredChain(
            chainIds,
            String(log.id),
            steps,
            parentId,
            byId,
            disallowNodeIds,
          )
        ) {
          chainIds = [];
        }

        // Fallback: compute via parent-walk on callbackLink.fromLogId.
        if (!chainIds.length) {
          chainIds = computeChainLogIdsByParentWalk(
            actor,
            String(log.id),
            steps,
            disallowNodeIds,
            byId,
          );
        }
      } catch (_) {
        // fall back to empty chain on error
        chainIds = [];
      }

      // Keep only the last N steps for display grouping.
      if (chainIds.length > steps) chainIds = chainIds.slice(-steps);

      // If logs were deleted, some IDs won't exist anymore. Keep the arc visible anyway.
      const presentChain = chainIds
        .map((id) => String(id))
        .filter((id) => byId.has(String(id)));

      if (!presentChain.length) continue;

      // Prevent overlapping arc blocks.
      if (presentChain.some((id) => usedArcIds.has(String(id)))) continue;
      for (const id of presentChain) usedArcIds.add(String(id));

      let maxTime = 0;
      for (const id of presentChain) {
        const item = byId.get(String(id));
        const t = getCreatedTimeKey(item);
        if (t > maxTime) maxTime = t;
      }

      const arcLabel = String(arcInfo?.arcLabel ?? "").trim();

      arcBlocks.push({
        arcId: String(log.id),
        ids: presentChain,
        maxTime,
        arcLabel,
      });
    }

    // Arc Order:
    // 1) Shorter arcs first (fewer logs in the arc chain)
    // 2) Tie-breaker: earlier completion first (latest log createdTime)
    arcBlocks.sort((a, b) => {
      const ld = (a.ids?.length ?? 0) - (b.ids?.length ?? 0);
      if (ld) return ld;
      return (
        (a.maxTime ?? Number.MAX_SAFE_INTEGER) -
        (b.maxTime ?? Number.MAX_SAFE_INTEGER)
      );
    });
    arcWrapGroups = arcBlocks.map((b) => ({
      arcId: b.arcId,
      // Store only the base label; numbering is applied at render time.
      arcLabel: String(b.arcLabel ?? ""),
      ids: b.ids,
    }));

    // ----- 2) Remaining logs (Chain Order > Date Order) -----
    const remainingIds = new Set(logItems.map((l) => String(l.id)));
    for (const g of arcWrapGroups)
      for (const id of g.ids) remainingIds.delete(String(id));

    const remainingItems = logItems.filter((l) =>
      remainingIds.has(String(l.id)),
    );
    const remainingById = new Map(remainingItems.map((l) => [String(l.id), l]));

    const parentByChildId = _getValidCallbackParentMap(actor, remainingItems);

    const orderComponent = (items) => {
      const itemById = new Map(items.map((i) => [String(i.id), i]));
      const childrenByParentId = new Map();
      const roots = [];

      for (const item of items) {
        const id = String(item.id);
        const parentId = parentByChildId.get(id);
        if (parentId && itemById.has(String(parentId))) {
          const key = String(parentId);
          if (!childrenByParentId.has(key)) childrenByParentId.set(key, []);
          childrenByParentId.get(key).push(id);
        } else {
          roots.push(id);
        }
      }

      const byTime = (ida, idb) =>
        getCreatedTimeKey(itemById.get(ida)) -
        getCreatedTimeKey(itemById.get(idb));

      roots.sort(byTime);
      for (const [pid, childIds] of childrenByParentId.entries()) {
        childIds.sort(byTime);
        childrenByParentId.set(pid, childIds);
      }

      const visited = new Set();
      const ordered = [];

      const visit = (id) => {
        if (visited.has(id)) return;
        visited.add(id);
        const it = itemById.get(id);
        if (it) ordered.push(it);
        const kids = childrenByParentId.get(String(id)) ?? [];
        for (const kid of kids) visit(kid);
      };

      for (const r of roots) visit(r);

      // Safety: append any remaining nodes deterministically.
      if (ordered.length !== items.length) {
        const remaining = items
          .map((i) => String(i.id))
          .filter((id) => !visited.has(id))
          .sort(byTime);
        for (const id of remaining) visit(id);
      }

      return ordered;
    };

    const components = _getLogChainComponents(actor, remainingItems);
    const normalized = components
      .map((items) => {
        const sorted = orderComponent(items);
        let minTime = Number.MAX_SAFE_INTEGER;
        for (const it of sorted) {
          const t = getCreatedTimeKey(it);
          if (t < minTime) minTime = t;
        }
        return { sorted, minKey: minTime };
      })
      .sort((a, b) => a.minKey - b.minKey);

    orderedIds = [
      ...arcWrapGroups.flatMap((g) => g.ids.map((id) => String(id))),
      ...normalized.flatMap((c) => c.sorted.map((i) => String(i.id))),
    ].filter((id) => byId.has(String(id)));

    // Indent only logs that are a valid callback child within the current chain rules.
    clearIndent();
    const indentChildIds = _getChainIndentChildLogIds(actor, logItems);
    for (const id of indentChildIds) {
      const el = byElId.get(String(id));
      if (el) el.classList.add("sta-callbacks-chain-child");
    }

    // Arc boxing/collapse is applied after we reorder the DOM.
  } else {
    // Fallback: treat as created.
    clearIndent();
    clearArcDecorations();
    const items = Array.from(logItems).sort(sortCreatedTime);
    orderedIds = items.map((i) => String(i.id));
  }

  // Insert logs above the Milestones / Arcs area, if present.
  // Fallback to the first milestone entry.
  const insertBeforeEl =
    milestoneTitleEl ?? milestoneHeaderEl ?? firstMilestoneEntryEl ?? null;

  if (insertBeforeEl) {
    for (const id of orderedIds) {
      const el = byElId.get(id);
      if (!el) continue;
      insertionParent.insertBefore(el, insertBeforeEl);
    }
  } else {
    for (const id of orderedIds) {
      const el = byElId.get(id);
      if (!el) continue;
      // No milestone area; keep logs below the log header when possible.
      if (logHeaderEl && logHeaderEl.parentElement === insertionParent) {
        insertionParent.insertBefore(el, logHeaderEl.nextSibling);
      } else {
        insertionParent.appendChild(el);
      }
    }
  }

  // ----- Completed Arc visualization (wrapper + collapse) -----
  if (sortMode === "chain") {
    try {
      const actorId = String(actor?.id ?? "");
      _hydrateFromActor(actor);
      const usedIds = new Set();

      /** @type {Array<{arcId:string, startId:string, ids:string[]}>} */
      const arcGroups = [];

      // Prefer using the chain-mode precomputed arc blocks so ordering is stable
      // and aligns with "Arc Order > Chain Order > Date Order".
      if (Array.isArray(arcWrapGroups) && arcWrapGroups.length) {
        for (const g of arcWrapGroups) {
          const ids = Array.isArray(g.ids)
            ? g.ids.map((x) => String(x)).filter(Boolean)
            : [];
          const present = ids.filter((id) => orderedIds.includes(String(id)));
          if (!present.length) continue;
          const startId = String(present[0]);
          arcGroups.push({
            arcId: String(g.arcId),
            startId,
            ids: present,
            arcLabel: String(g.arcLabel ?? ""),
          });
        }
      }

      const applyCollapsedState = (wrapperEl, arcId) => {
        const collapsed = _isArcCollapsed(actorId, arcId);
        wrapperEl.classList.toggle("is-collapsed", collapsed);

        const icons = Array.from(
          wrapperEl.querySelectorAll(
            '.sta-arc-collapse-btn i[class*="fa-chevron"]',
          ),
        );
        for (const icon of icons) {
          icon.classList.toggle("fa-chevron-right", collapsed);
          icon.classList.toggle("fa-chevron-down", !collapsed);
        }
      };

      for (let arcIndex = 0; arcIndex < arcGroups.length; arcIndex += 1) {
        const { arcId, startId, ids } = arcGroups[arcIndex];
        const arcLabelBase = String(arcGroups[arcIndex]?.arcLabel ?? "").trim();
        // Back-compat: if older data already stored a full label like "Arc 1 (...)",
        // use it as-is. Otherwise, render a stable "Arc N" + optional "(Title)".
        const arcLabelFull = arcLabelBase.startsWith("Arc ")
          ? arcLabelBase
          : arcLabelBase
            ? `Arc ${arcIndex + 1} (${arcLabelBase})`
            : `Arc ${arcIndex + 1}`;

        const onToggle = (ev) => {
          ev?.preventDefault?.();
          ev?.stopPropagation?.();
          const next = !_isArcCollapsed(actorId, arcId);
          _setArcCollapsed(actorId, arcId, next, actor);
          applyCollapsedState(wrapper, arcId);
        };

        const startEl = byElId.get(String(startId));
        if (!startEl) continue;

        // Create wrapper and move arc log elements inside.
        const wrapper = document.createElement("div");
        wrapper.className = "sta-callbacks-arc-group";
        wrapper.dataset.staArcId = arcId;
        wrapper.dataset.staArcLabel = arcLabelFull;
        insertionParent.insertBefore(wrapper, startEl);

        // Add a title row for the collapsed state (when all logs are hidden).
        const titleRow = document.createElement("div");
        titleRow.className = "sta-callbacks-arc-title";
        titleRow.dataset.staArcId = arcId;
        titleRow.dataset.staArcLabel = arcLabelFull;
        wrapper.appendChild(titleRow);

        // Always make the title row act as the collapse/expand control.
        titleRow.addEventListener("click", onToggle);
        titleRow.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter" || ev.key === " ") onToggle(ev);
        });
        titleRow.setAttribute("role", "button");
        titleRow.tabIndex = 0;

        const titleBtn = document.createElement("span");
        titleBtn.className = "sta-arc-collapse-btn";
        titleBtn.title = `${arcLabelFull} (collapse/expand)`;
        titleBtn.setAttribute("aria-label", titleBtn.title);
        titleBtn.setAttribute("role", "button");
        titleBtn.tabIndex = 0;

        // IMPORTANT: arcLabelFull can include user-provided text; avoid innerHTML.
        const icon = document.createElement("i");
        icon.className = "fa-solid fa-chevron-down";
        titleBtn.appendChild(icon);

        const label = document.createElement("span");
        label.className = "sta-arc-collapse-label";
        label.textContent = arcLabelFull;
        titleBtn.appendChild(label);

        titleBtn.addEventListener("click", onToggle);
        titleBtn.addEventListener("keydown", (ev) => {
          if (ev.key === "Enter" || ev.key === " ") onToggle(ev);
        });
        titleRow.appendChild(titleBtn);

        // Edit arc title (stored on the arc-end log item).
        try {
          const editBtn = document.createElement("span");
          editBtn.className = "sta-arc-title-edit";
          editBtn.title = "Edit arc title";
          editBtn.setAttribute("aria-label", editBtn.title);
          editBtn.setAttribute("role", "button");
          editBtn.tabIndex = 0;
          editBtn.innerHTML = '<i class="fas fa-pen"></i>';

          const onEdit = async (ev) => {
            ev?.preventDefault?.();
            ev?.stopPropagation?.();

            const DialogV2 = globalThis.foundry?.applications?.api?.DialogV2;
            if (!DialogV2?.input) return;

            const arcEndLog = actor?.items?.get?.(String(arcId)) ?? null;
            if (!arcEndLog || arcEndLog.type !== "log") return;
            if (arcEndLog.isOwner !== true && game?.user?.isGM !== true) return;
            const arcInfo =
              arcEndLog.system?.arcInfo ??
              arcEndLog.getFlag?.(MODULE_ID, "arcInfo") ??
              null;
            if (arcInfo?.isArc !== true) return;

            const current = String(arcInfo?.arcLabel ?? "");
            const safe = foundry.utils.escapeHTML(String(current));

            const content = `
              <form>
                <div class="form-group">
                  <label>Arc title</label>
                  <input type="text" name="arcTitle" value="${safe}" />
                  <p class="hint">Shown as “Arc N (title)”. Leave blank for “Arc N”.</p>
                </div>
              </form>
            `;

            const result = await DialogV2.input({
              classes: ["sta-officers-log"],
              window: { title: "Edit Arc Title" },
              modal: false,
              rejectClose: false,
              content,
              ok: { label: "Save" },
              cancel: { label: "Cancel" },
            });

            if (!result) return;
            const next = String(result.arcTitle ?? "").trim();

            const update = {};
            // Use empty string as a deliberate "no title" sentinel.
            const currentArcInfo =
              arcEndLog.system?.arcInfo ??
              arcEndLog.getFlag?.(MODULE_ID, "arcInfo") ??
              {};
            update["system.arcInfo"] = { ...currentArcInfo, arcLabel: next };
            await arcEndLog.update(update, {
              render: false,
              renderSheet: false,
            });
          };

          editBtn.addEventListener("click", onEdit);
          editBtn.addEventListener("keydown", (ev) => {
            if (ev.key === "Enter" || ev.key === " ") void onEdit(ev);
          });

          titleRow.appendChild(editBtn);
        } catch (_) {
          // edit button is optional UI
        }

        for (const id of ids) {
          const el = byElId.get(String(id));
          if (!el) continue;
          el.dataset.staCallbacksArcId = arcId;
          wrapper.appendChild(el);
        }

        // We intentionally do NOT inject another collapse control into each log row.
        // The title row is always visible and acts as the control.

        applyCollapsedState(wrapper, arcId);
      }

      // ----- "No Value Used" grouping -----
      // Group logs with "No Value Used" primary value if there are 2 or more.
      try {
        const noValueValueItems = actor.items.filter(
          (i) => i?.type === "value",
        );
        const noValueLogIds = [];
        for (const log of logItems) {
          const primaryId = getPrimaryValueIdForLog(
            actor,
            log,
            noValueValueItems,
          );
          if (isNoValueUsedId(primaryId)) {
            noValueLogIds.push(String(log.id));
          }
        }

        if (noValueLogIds.length >= 2) {
          const noValueGroupId = NO_VALUE_USED_ID;
          const noValueLabel = t(
            "sta-officers-log.logSheet.noValueUsedGroupTitle",
          );

          // Create the wrapper - we'll insert it at the end of the logs section.
          const onNoValueToggle = (ev) => {
            ev?.preventDefault?.();
            ev?.stopPropagation?.();
            const next = !_isArcCollapsed(actorId, noValueGroupId);
            _setArcCollapsed(actorId, noValueGroupId, next, actor);
            applyCollapsedState(noValueWrapper, noValueGroupId);
          };

          const noValueWrapper = document.createElement("div");
          noValueWrapper.className =
            "sta-callbacks-arc-group sta-no-value-group";
          noValueWrapper.dataset.staArcId = noValueGroupId;
          noValueWrapper.dataset.staArcLabel = noValueLabel;

          // Insert at the end of logs (before milestones if present).
          if (insertBeforeEl) {
            insertionParent.insertBefore(noValueWrapper, insertBeforeEl);
          } else {
            insertionParent.appendChild(noValueWrapper);
          }

          const noValueTitleRow = document.createElement("div");
          noValueTitleRow.className =
            "sta-callbacks-arc-title sta-no-value-title";
          noValueTitleRow.dataset.staArcId = noValueGroupId;
          noValueTitleRow.dataset.staArcLabel = noValueLabel;
          noValueWrapper.appendChild(noValueTitleRow);

          noValueTitleRow.addEventListener("click", onNoValueToggle);
          noValueTitleRow.addEventListener("keydown", (ev) => {
            if (ev.key === "Enter" || ev.key === " ") onNoValueToggle(ev);
          });
          noValueTitleRow.setAttribute("role", "button");
          noValueTitleRow.tabIndex = 0;

          const noValueTitleBtn = document.createElement("span");
          noValueTitleBtn.className = "sta-arc-collapse-btn";
          noValueTitleBtn.title = `${noValueLabel} (collapse/expand)`;
          noValueTitleBtn.setAttribute("aria-label", noValueTitleBtn.title);
          noValueTitleBtn.setAttribute("role", "button");
          noValueTitleBtn.tabIndex = 0;

          const noValueIcon = document.createElement("i");
          noValueIcon.className = "fa-solid fa-chevron-down";
          noValueTitleBtn.appendChild(noValueIcon);

          const noValueLabelEl = document.createElement("span");
          noValueLabelEl.className = "sta-arc-collapse-label";
          noValueLabelEl.textContent = noValueLabel;
          noValueTitleBtn.appendChild(noValueLabelEl);

          noValueTitleBtn.addEventListener("click", onNoValueToggle);
          noValueTitleBtn.addEventListener("keydown", (ev) => {
            if (ev.key === "Enter" || ev.key === " ") onNoValueToggle(ev);
          });
          noValueTitleRow.appendChild(noValueTitleBtn);

          // Move all "No Value Used" logs into the wrapper.
          for (const id of noValueLogIds) {
            const el = byElId.get(String(id));
            if (!el) continue;
            el.dataset.staCallbacksArcId = noValueGroupId;
            noValueWrapper.appendChild(el);
          }

          applyCollapsedState(noValueWrapper, noValueGroupId);
        }
      } catch (_) {
        // "No Value Used" grouping is cosmetic; continue without it
      }
    } catch (_) {
      // arc grouping is cosmetic; continue without it
    }
  }

  // ----- Logs UI tweaks: callback header + tooltips -----
  try {
    const tooltip = "Used for Callback";

    // Replace the column header text "Callback?" with the reverse-arrow icon.
    const headerContainer =
      section.querySelector(":scope > div.header.row.item") ??
      section.querySelector(":scope > li.row.header") ??
      section.querySelector(":scope > .header") ??
      null;

    if (headerContainer) {
      const candidates = Array.from(
        headerContainer.querySelectorAll("*"),
      ).filter((el) => {
        if (!(el instanceof HTMLElement)) return false;
        if (el.children?.length) return false;
        const text = String(el.textContent ?? "").trim();
        return /^callback\?$/i.test(text);
      });

      for (const el of candidates) {
        el.innerHTML = '<i class="fa-solid fa-reply"></i>';
        el.title = tooltip;
        el.setAttribute("aria-label", tooltip);
        el.classList.add("sta-callbacks-callback-header-icon");
      }
    }

    // Add tooltips to all callback toggles in log rows.
    const toggles = section.querySelectorAll(
      'li.row.entry[data-item-type="log"] a.value-used.control.toggle, li.row.entry[data-item-type="log"] .value-used.control.toggle',
    );
    for (const el of Array.from(toggles)) {
      if (!(el instanceof HTMLElement)) continue;
      el.title = tooltip;
      el.setAttribute("aria-label", tooltip);
    }
  } catch (_) {
    // tooltip injection is non-critical
  }

  // Removed: milestone button replacement code moved to the top of the function
  // so it runs regardless of sort mode
}

// ─────────────────────────────────────────────────────────────────────────────
// Debounced refresh: re-apply sorting to open STA character sheets in-place
// ─────────────────────────────────────────────────────────────────────────────

const _pendingRefreshActorIds = new Set();
let _refreshDebounceTimer = null;
const REFRESH_DEBOUNCE_MS = 50;

/** Returns the root HTMLElement for an ApplicationV2 instance. */
function _getApplicationRootElement(app) {
  return app?.element instanceof HTMLElement ? app.element : null;
}

function _doRefreshMissionLogSortingForActorId(actorId) {
  const maybe = (app) => {
    try {
      if (
        !app?.id?.startsWith?.("STACharacterSheet2e") &&
        !app?.id?.startsWith?.("LcarsCharacterSheet2e")
      )
        return;
      if (!actorId || app?.actor?.id !== actorId) return;
      const root = _getApplicationRootElement(app);
      if (!root) return;

      const actor = app.actor;
      const mode = getMissionLogSortModeForActor(actor);
      applyMissionLogSorting(root, actor, mode);
    } catch (_) {
      // sorting is non-critical
    }
  };

  try {
    for (const w of Object.values(ui?.windows ?? {})) maybe(w);
  } catch (_) {
    // windows may be unavailable
  }

  try {
    const instances = foundry?.applications?.instances;
    if (instances) {
      for (const app of instances.values()) maybe(app);
    }
  } catch (_) {
    // instances API may not exist
  }
}

function _flushPendingRefreshes() {
  _refreshDebounceTimer = null;
  const actorIds = Array.from(_pendingRefreshActorIds);
  _pendingRefreshActorIds.clear();
  for (const actorId of actorIds) {
    _doRefreshMissionLogSortingForActorId(actorId);
  }
}

/**
 * Re-applies mission-log sorting to any already-open STA character sheets for this actor.
 * Debounced to coalesce multiple rapid calls into one.
 */
export function refreshMissionLogSortingForActorId(actorId) {
  if (!actorId) return;
  _pendingRefreshActorIds.add(actorId);
  if (_refreshDebounceTimer) return;
  _refreshDebounceTimer = setTimeout(
    _flushPendingRefreshes,
    REFRESH_DEBOUNCE_MS,
  );
}
