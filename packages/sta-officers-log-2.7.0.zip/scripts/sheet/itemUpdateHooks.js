/**
 * Item Update Hooks
 *
 * Registers Foundry hooks for item lifecycle events (create, update, render, close)
 * to keep character sheets responsive and maintain data integrity for logs,
 * milestones, and callback chains.
 */

import { MODULE_ID } from "../core/constants.js";
import { isPlainObject } from "../core/utils.js";
import { formatChosenBenefitLabel } from "../milestones/benefits.js";
import {
  isDirectiveValueId,
  directiveIconPath,
} from "../directives/directives.js";
import { getLogIconPathForValue, getStaDefaultIcon } from "../values/values.js";
import { isValueTrauma } from "../values/trauma/trauma.js";
import { areSheetEnhancementsEnabled } from "../settings/clientSettings.js";
import {
  getActorFromAppOrItem,
  getItemFromApp,
  rerenderOpenStaSheetsForActorId as refreshOpenSheet,
} from "./sheetUtils.js";
import { refreshMissionLogSortingForActorId } from "../log/logSorting.js";
import {
  enforceUniqueFromLogIdTargets,
  syncCallbackTargetUsedFlags,
} from "../log/callbackSourceButtons.js";
import {
  isLogBeingNormalized,
  isActorBeingNormalized,
  markLogNormalizing,
  markActorNormalizing,
} from "../log/normalization.js";
import { installInlineLogChainLinkControls } from "../log/logLinkControls.js";
import { installLogMetaCollapsible } from "../log/logMetaCollapsible.js";

let _staOfficersLogMilestoneUpdateHookInstalled = false;
let _staOfficersLogItemSheetRenderHookInstalled = false;

/**
 * Install hooks for keeping character sheets responsive when items are edited.
 * This includes createItem, updateItem, renderItemSheet, and closeItemSheet hooks.
 */
export function installItemUpdateHooks() {
  // Keep character sheets responsive when milestones are edited manually.
  if (!_staOfficersLogMilestoneUpdateHookInstalled) {
    _staOfficersLogMilestoneUpdateHookInstalled = true;

    Hooks.on("createItem", (item) => {
      try {
        if (!areSheetEnhancementsEnabled()) return;
        if (item?.type !== "milestone") return; //we hook on the creation of all items but then only continue for milestones.
        const actor = item?.parent; // find out who the character actor is who has the milestone.
        if (!actor?.id) return;
        // Avoid full character-sheet rerenders (they flash/steal focus). We only
        // need to refresh the log ordering/arc wrappers.
        refreshMissionLogSortingForActorId(actor.id);
      } catch (_) {
        // ignore
      }
    });

    Hooks.on("updateItem", (item, changes) => {
      try {
        // Keep milestone names in sync when a created item is renamed.
        // This is independent of sheet UX enhancements.
        if (changes?.name !== undefined) {
          const itemType = String(item?.type ?? "");
          const supported =
            itemType === "focus" ||
            itemType === "talent" ||
            itemType === "shipTalent" ||
            itemType === "value";

          if (supported && item?.id) {
            const newItemName = String(item.name ?? "").trim();
            if (newItemName) {
              void (async () => {
                const findLinkedMilestones = (actor) => {
                  try {
                    return actor.items.filter((it) => {
                      if (it?.type !== "milestone") return false;
                      const benefit =
                        it.getFlag?.(MODULE_ID, "milestoneBenefit") ?? null;
                      const createdItemId = benefit?.createdItemId
                        ? String(benefit.createdItemId)
                        : "";
                      return createdItemId && createdItemId === String(item.id);
                    });
                  } catch (_) {
                    return [];
                  }
                };

                // If renamed item is on a character, only that character can have the matching milestone.
                // Ship talents live on the Group Ship actor, so we search characters that own them.
                // Optimization: avoid iterating all actors when possible.
                const candidateActors = (() => {
                  const parent = item?.parent ?? null;
                  if (parent?.type === "character") return [parent];
                  // For ship talents, only search actors that might reference this item.
                  // Skip the expensive all-actors search if the item has no parent.
                  if (!parent) return [];
                  // Only ship talents on non-character parents need broader search
                  if (itemType !== "shipTalent") return [];
                  return (game.actors ?? []).filter(
                    (a) => a?.type === "character",
                  );
                })();

                const nameUpdates = [];
                const flagUpdates = [];

                for (const actor of candidateActors) {
                  const linkedMilestones = findLinkedMilestones(actor);
                  if (!linkedMilestones.length) continue;

                  for (const ms of linkedMilestones) {
                    const benefit =
                      ms.getFlag?.(MODULE_ID, "milestoneBenefit") ?? null;
                    const syncPolicy = String(benefit?.syncPolicy ?? "always");
                    const syncedOnce = Boolean(benefit?.syncedOnce);
                    if (syncPolicy === "once" && syncedOnce) continue;

                    const benefitAction = (() => {
                      const fromFlag = benefit?.action
                        ? String(benefit.action)
                        : "";
                      if (fromFlag) return fromFlag;

                      // Reasonable fallbacks (older milestones without flags)
                      if (itemType === "value") return "arcValue";
                      if (itemType === "shipTalent" || itemType === "talent")
                        return "arcShipTalent";
                      return itemType;
                    })();

                    const desiredName = formatChosenBenefitLabel({
                      applied: true,
                      action: benefitAction,
                      name: newItemName,
                    });

                    if (!desiredName) continue;
                    if (ms?.name !== desiredName)
                      nameUpdates.push({ ms, desiredName });
                    if (syncPolicy === "once" && !syncedOnce)
                      flagUpdates.push({ ms, benefit });
                  }
                }

                await Promise.all(
                  nameUpdates.map(({ ms, desiredName }) =>
                    ms.update({ name: desiredName }).catch(() => {}),
                  ),
                );
                await Promise.all(
                  flagUpdates.map(({ ms, benefit }) =>
                    ms
                      .setFlag(MODULE_ID, "milestoneBenefit", {
                        ...(isPlainObject(benefit) ? benefit : {}),
                        syncedOnce: true,
                      })
                      .catch(() => {}),
                  ),
                );
              })();
            }
          }
        }

        if (!areSheetEnhancementsEnabled()) return;

        // If a Milestone item is being edited in its own sheet, keep that sheet in front.
        // This mirrors the Log-sheet behavior, but only refocuses when the user is
        // actively interacting with the Milestone sheet (so we don't steal focus).
        if (item?.type === "milestone") {
          const sheet = item?.sheet;
          if (sheet?.rendered) {
            const refocus = () => {
              try {
                const activeEl = document.activeElement;
                const rootEl = sheet?.element;

                if (
                  !(
                    activeEl instanceof HTMLElement &&
                    rootEl instanceof HTMLElement &&
                    rootEl.contains(activeEl)
                  )
                ) {
                  return;
                }

                sheet.bringToFront?.();
              } catch (_) {
                // ignore
              }
            };

            setTimeout(refocus, 25);
            setTimeout(refocus, 125);
          }
        }

        // If a Log item is being edited in its own sheet, keep that sheet in front.
        // Some sheet rerenders (including the character sheet) can steal focus.
        if (item?.type === "log") {
          const actor = item?.parent ?? null;
          const sheet = item?.sheet;
          if (sheet?.rendered) {
            // Defer to allow any actor/character-sheet rerenders to finish first.
            // Do a second attempt a bit later in case another window is raised.
            const refocus = () => {
              try {
                // Only refocus if the user is actively interacting with THIS Log sheet.
                // Otherwise this can steal focus from other item sheets (e.g. Milestones)
                // when log sorting updates occur.
                const activeEl = document.activeElement;
                const rootEl = sheet?.element;

                if (
                  !(
                    activeEl instanceof HTMLElement &&
                    rootEl instanceof HTMLElement &&
                    rootEl.contains(activeEl)
                  )
                ) {
                  return;
                }

                sheet.bringToFront?.();
              } catch (_) {
                // ignore
              }
            };
            setTimeout(refocus, 25);
            setTimeout(refocus, 125);
          }

          // If the Log's chain-related data changed, refresh open character sheets
          // (without stealing focus) AFTER the save/update is complete.
          const hasChainFlagChange = (() => {
            try {
              const base = `flags.${MODULE_ID}.`;
              return (
                changes?.system?.callbackLink !== undefined ||
                changes?.system?.primaryValueId !== undefined ||
                changes?.system?.arcInfo !== undefined ||
                changes?.system?.callbackLinkDisabled !== undefined ||
                foundry.utils.getProperty(changes, `${base}callbackLink`) !==
                  undefined ||
                foundry.utils.getProperty(
                  changes,
                  `${base}callbackLink.fromLogId`,
                ) !== undefined ||
                foundry.utils.getProperty(
                  changes,
                  `${base}callbackLink.valueId`,
                ) !== undefined ||
                foundry.utils.getProperty(changes, `${base}primaryValueId`) !==
                  undefined ||
                foundry.utils.getProperty(changes, `${base}arcInfo`) !==
                  undefined ||
                foundry.utils.getProperty(
                  changes,
                  `${base}callbackLinkDisabled`,
                ) !== undefined
              );
            } catch (_) {
              return false;
            }
          })();

          const hasCallbackTargetDedupChange = (() => {
            try {
              const base = `flags.${MODULE_ID}.`;
              return (
                changes?.system?.callbackLink !== undefined ||
                changes?.system?.callbackLinkDisabled !== undefined ||
                foundry.utils.getProperty(changes, `${base}callbackLink`) !==
                  undefined ||
                foundry.utils.getProperty(
                  changes,
                  `${base}callbackLink.fromLogId`,
                ) !== undefined ||
                foundry.utils.getProperty(
                  changes,
                  `${base}callbackLinkDisabled`,
                ) !== undefined
              );
            } catch (_) {
              return false;
            }
          })();

          if (actor?.type === "character" && actor?.id && hasChainFlagChange) {
            // Normalization writes (enforcing uniqueness, syncing used flags) must only
            // run on a client that can actually update the actor, otherwise Foundry logs
            // permission errors for non-owners.
            const canWriteActor = (() => {
              try {
                return (
                  game.user?.isGM === true ||
                  actor?.isOwner === true ||
                  (typeof actor?.testUserPermission === "function" &&
                    actor.testUserPermission(game.user, "OWNER"))
                );
              } catch (_) {
                return false;
              }
            })();

            // Normalize flags for consistent chain behavior.
            const logId = item?.id ? String(item.id) : "";
            if (logId && !isLogBeingNormalized(logId)) {
              markLogNormalizing(logId, true);
              void (async () => {
                try {
                  // Enforce: each callback target (fromLogId) can only be used once.
                  // Trigger only when callbackLink-related fields change.
                  if (
                    hasCallbackTargetDedupChange &&
                    !isActorBeingNormalized(String(actor.id))
                  ) {
                    markActorNormalizing(String(actor.id), true);
                    try {
                      if (canWriteActor) {
                        await enforceUniqueFromLogIdTargets(actor, {
                          editedLogId: logId,
                        });

                        // Keep system.used in sync with whether a log is a callback target.
                        await syncCallbackTargetUsedFlags(actor);
                      }
                    } catch (_) {
                      // ignore
                    } finally {
                      // Clear guard on next tick to prevent loops.
                      setTimeout(
                        () => markActorNormalizing(String(actor.id), false),
                        0,
                      );
                    }
                  }

                  const primaryValueId = String(
                    item.system?.primaryValueId ||
                      item.getFlag?.(MODULE_ID, "primaryValueId") ||
                      "",
                  );
                  const link =
                    item.system?.callbackLink ??
                    item.getFlag?.(MODULE_ID, "callbackLink") ??
                    null;
                  const fromLogId = String(link?.fromLogId ?? "");
                  const linkValueId = String(link?.valueId ?? "");

                  const update = {};

                  const callbackLinkTouched = (() => {
                    try {
                      const base = `flags.${MODULE_ID}.`;
                      return (
                        changes?.system?.callbackLink !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}callbackLink`,
                        ) !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}callbackLink.fromLogId`,
                        ) !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}callbackLink.valueId`,
                        ) !== undefined
                      );
                    } catch (_) {
                      return false;
                    }
                  })();

                  const primaryValueTouched = (() => {
                    try {
                      return (
                        changes?.system?.primaryValueId !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `flags.${MODULE_ID}.primaryValueId`,
                        ) !== undefined
                      );
                    } catch (_) {
                      return false;
                    }
                  })();

                  const arcInfoTouched = (() => {
                    try {
                      const base = `flags.${MODULE_ID}.`;
                      return (
                        changes?.system?.arcInfo !== undefined ||
                        foundry.utils.getProperty(changes, `${base}arcInfo`) !==
                          undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}arcInfo.isArc`,
                        ) !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}arcInfo.steps`,
                        ) !== undefined ||
                        foundry.utils.getProperty(
                          changes,
                          `${base}arcInfo.valueId`,
                        ) !== undefined
                      );
                    } catch (_) {
                      return false;
                    }
                  })();

                  const arcInfo =
                    item.system?.arcInfo ??
                    item.getFlag?.(MODULE_ID, "arcInfo") ??
                    null;
                  const isArc = arcInfo?.isArc === true;
                  const shouldNormalizeArc =
                    arcInfoTouched || (callbackLinkTouched && isArc);

                  // Only treat callbackLinkDisabled as an explicit override when the user actually
                  // edited the callbackLink field.
                  if (callbackLinkTouched) {
                    if (!fromLogId) {
                      // User selected "No link". Clear callbackLink and mark as explicitly disabled
                      // so milestone-derived links don't reassert it.
                      update["system.callbackLink"] = null;
                      update["system.callbackLinkDisabled"] = true;
                    } else {
                      // User selected a real callback link.
                      update["system.callbackLinkDisabled"] = false;
                      // Keep callbackLink.valueId aligned with Primary Value.
                      if (primaryValueId && linkValueId !== primaryValueId) {
                        update["system.callbackLink"] = {
                          ...link,
                          valueId: primaryValueId,
                        };
                      }
                    }
                  }

                  // Sync log icon to Primary Value (or default) after save.
                  // Also set createdWithTrauma flag based on whether the value is currently a trauma.
                  if (primaryValueTouched) {
                    try {
                      if (
                        primaryValueId &&
                        !isDirectiveValueId(primaryValueId)
                      ) {
                        const valueItem = actor.items.get(primaryValueId);
                        if (valueItem?.type === "value") {
                          // Record whether this log was created with a trauma as its primary value.
                          // This flag persists so logs keep their V# or T# prefix even if the value's
                          // trauma status later changes.
                          const valueIsTrauma = isValueTrauma(valueItem);
                          update["system.createdWithTrauma"] = valueIsTrauma;

                          // Compute icon using the new trauma status and value's current position
                          const desiredImg = getLogIconPathForValue(
                            actor,
                            primaryValueId,
                            valueIsTrauma,
                          );
                          if (
                            desiredImg &&
                            String(item.img ?? "") !== String(desiredImg)
                          ) {
                            update.img = desiredImg;
                          }
                        } else {
                          // Value not found - use default icon
                          const desiredImg = getStaDefaultIcon();
                          if (
                            desiredImg &&
                            String(item.img ?? "") !== String(desiredImg)
                          ) {
                            update.img = desiredImg;
                          }
                        }
                      } else if (
                        primaryValueId &&
                        isDirectiveValueId(primaryValueId)
                      ) {
                        const desiredImg = directiveIconPath();
                        if (
                          desiredImg &&
                          String(item.img ?? "") !== String(desiredImg)
                        ) {
                          update.img = desiredImg;
                        }
                      } else {
                        // No primary value - use default icon
                        const desiredImg = getStaDefaultIcon();
                        if (
                          desiredImg &&
                          String(item.img ?? "") !== String(desiredImg)
                        ) {
                          update.img = desiredImg;
                        }
                      }
                    } catch (_) {
                      // ignore
                    }
                  }

                  // Normalize arc completion metadata (chainLogIds) after save.
                  if (shouldNormalizeArc) {
                    try {
                      if (!isArc) {
                        // If the sheet wrote an arcInfo object with isArc=false, clear it out.
                        update["system.arcInfo"] = null;
                      } else {
                        const rawSteps = Number(arcInfo?.steps ?? 0);
                        const steps =
                          Number.isFinite(rawSteps) && rawSteps > 0
                            ? Math.floor(rawSteps)
                            : 1;

                        const arcValueId = String(
                          arcInfo?.valueId ??
                            primaryValueId ??
                            linkValueId ??
                            "",
                        );

                        if (!arcValueId) {
                          // Invalid arc state: drop arc completion.
                          update["system.arcInfo"] = null;
                        } else {
                          const computeChainLogIdsByParentWalk = (
                            actorDoc,
                            endLogId,
                            maxSteps,
                            disallowNodeIds,
                          ) => {
                            try {
                              const steps = Number(maxSteps);
                              if (!Number.isFinite(steps) || steps <= 0)
                                return [];
                              const actorItems = actorDoc?.items ?? null;
                              if (!actorItems?.get) return [];

                              const result = [];
                              const seen = new Set();
                              let cur = endLogId ? String(endLogId) : "";

                              while (cur && result.length < steps) {
                                const id = String(cur);
                                if (seen.has(id)) break;
                                seen.add(id);

                                const curItem = actorItems.get(id);
                                if (!curItem || curItem.type !== "log") break;

                                result.push(id);

                                const parentRaw =
                                  (
                                    curItem.system?.callbackLink ??
                                    curItem.getFlag?.(MODULE_ID, "callbackLink")
                                  )?.fromLogId ?? "";
                                const parentId = parentRaw
                                  ? String(parentRaw)
                                  : "";
                                if (!parentId) break;

                                if (disallowNodeIds?.has?.(parentId)) break;

                                const parentItem = actorItems.get(parentId);
                                if (!parentItem || parentItem.type !== "log")
                                  break;

                                cur = parentId;
                              }

                              return result.reverse();
                            } catch (_) {
                              return [];
                            }
                          };

                          // Disallow reusing nodes already consumed by OTHER arcs.
                          const disallowNodeIds = new Set();
                          try {
                            const actorLogs = Array.from(
                              actor.items ?? [],
                            ).filter((i) => i?.type === "log");
                            for (const other of actorLogs) {
                              if (String(other.id) === String(item.id))
                                continue;
                              const otherArc =
                                other.system?.arcInfo ??
                                other.getFlag?.(MODULE_ID, "arcInfo") ??
                                null;
                              if (otherArc?.isArc !== true) continue;
                              const otherChain = Array.isArray(
                                otherArc.chainLogIds,
                              )
                                ? otherArc.chainLogIds
                                : [];
                              for (const id of otherChain) {
                                if (id) disallowNodeIds.add(String(id));
                              }
                            }
                          } catch (_) {
                            // ignore
                          }

                          let chainLogIds = [];
                          try {
                            chainLogIds = computeChainLogIdsByParentWalk(
                              actor,
                              String(item.id),
                              steps,
                              disallowNodeIds,
                            );
                          } catch (_) {
                            chainLogIds = [];
                          }

                          const nextArcInfo = {
                            ...(isPlainObject(arcInfo) ? arcInfo : {}),
                            isArc: true,
                            steps,
                            valueId: arcValueId,
                            chainLogIds,
                            // Persisted, user-editable arc title. Do NOT derive it from the
                            // Value name so renaming a Value doesn't rename arcs.
                            arcLabel: isPlainObject(arcInfo)
                              ? String(arcInfo.arcLabel ?? "")
                              : "",
                          };

                          const normalizeIdArray = (arr) =>
                            (Array.isArray(arr) ? arr : [])
                              .map((x) => String(x))
                              .filter(Boolean);
                          const arraysEqual = (a, b) => {
                            const aa = normalizeIdArray(a);
                            const bb = normalizeIdArray(b);
                            if (aa.length !== bb.length) return false;
                            for (let i = 0; i < aa.length; i += 1) {
                              if (aa[i] !== bb[i]) return false;
                            }
                            return true;
                          };

                          // If we're only normalizing due to callbackLink changes,
                          // avoid churning arcInfo unless the chain actually changed.
                          if (
                            arcInfoTouched ||
                            !arraysEqual(arcInfo?.chainLogIds, chainLogIds)
                          ) {
                            update["system.arcInfo"] = nextArcInfo;
                          }
                        }
                      }
                    } catch (_) {
                      // ignore
                    }
                  }

                  // Only a client with write permission should apply normalization writes.
                  if (canWriteActor && Object.keys(update).length) {
                    await item.update(update, { renderSheet: false });
                  }
                } catch (_) {
                  // ignore
                } finally {
                  // Clear guard on next tick so other legitimate updates still work.
                  setTimeout(() => markLogNormalizing(logId, false), 0);
                }
              })();
            }

            // Refresh character sheet sorting/indentation without focus stealing.
            setTimeout(() => {
              try {
                refreshMissionLogSortingForActorId(actor.id);
              } catch (_) {
                // ignore
              }
            }, 0);
          }

          return;
        }

        if (item?.type !== "milestone") return;
        const actor = item?.parent;
        if (!actor?.id) return;

        // Only rerender when the milestone's associated logs / arc-ness changes.
        const system = changes?.system ?? {};
        const hasChildChange =
          Object.keys(system).some((k) => /^child[A-Z]$/.test(k)) ||
          system?.arc !== undefined;
        if (!hasChildChange) return;

        // Avoid full character-sheet rerenders (they flash/steal focus). We only
        // need to refresh the log ordering/arc wrappers.
        refreshMissionLogSortingForActorId(actor.id);
      } catch (_) {
        // ignore
      }
    });
  }

  // Compatibility: some environments still emit classic document-sheet hooks for item sheets.
  // Installing this fallback keeps our Log item sheet UI (including the "Edit Log Data" section)
  // working even if renderApplicationV2 isn't fired for that sheet.
  if (!_staOfficersLogItemSheetRenderHookInstalled) {
    _staOfficersLogItemSheetRenderHookInstalled = true;

    Hooks.on("renderItemSheet", async (app, html) => {
      try {
        if (!areSheetEnhancementsEnabled()) return;

        const item =
          app?.object ??
          app?.item ??
          (typeof getItemFromApp === "function" ? getItemFromApp(app) : null);
        if (!item) return;

        const root = html instanceof HTMLElement ? html : null;
        if (!root) return;

        if (item?.type === "log") {
          try {
            const actor = getActorFromAppOrItem(app, item);
            if (actor?.type === "character") {
              installInlineLogChainLinkControls(root, actor, item);
            }
          } catch (_) {
            // ignore
          }

          await installLogMetaCollapsible(root, item);
        }
      } catch (_) {
        // ignore
      }
    });

    // Re-render the parent character sheet when a log or milestone item sheet is closed.
    // This ensures changes made in the item sheet are immediately reflected on the character sheet.
    Hooks.on("closeItemSheet", (app) => {
      try {
        const item =
          app?.object ??
          app?.item ??
          (typeof getItemFromApp === "function" ? getItemFromApp(app) : null);
        if (!item) return;

        const itemType = item?.type;
        if (itemType !== "log" && itemType !== "milestone") return;

        const actor = getActorFromAppOrItem(app, item);
        if (!actor?.id || actor?.type !== "character") return;

        refreshOpenSheet(actor.id);
      } catch (_) {
        // ignore
      }
    });
  }
}
