import { MODULE_ID } from "../core/constants.js";
import { t } from "../core/i18n.js";
import { CompendiumPickerSettingsApp } from "./compendiumPickerSettingsApp.js";

export const FOCUS_PICKER_CUSTOM_COMPENDIUM_SETTING =
  "focusPickerCustomCompendium";

export function parseCompendiumPackKeys(rawValue) {
  const raw = rawValue ?? "";

  // Backwards compatible: setting is stored as a String but we accept
  // comma-separated values ("module.packA, module.packB").
  if (Array.isArray(raw)) {
    return Array.from(
      new Set(
        raw.map((v) => String(v ?? "").trim()).filter((v) => v.length > 0),
      ),
    );
  }

  return Array.from(
    new Set(
      String(raw)
        .split(",")
        .map((v) => v.trim())
        .filter((v) => v.length > 0),
    ),
  );
}

export function registerFocusPickerSettings() {
  game.settings.register(MODULE_ID, FOCUS_PICKER_CUSTOM_COMPENDIUM_SETTING, {
    name: t("sta-officers-log.settings.focusPickerCustomCompendium.name"),
    hint: t("sta-officers-log.settings.focusPickerCustomCompendium.hint"),
    scope: "world",
    config: false,
    restricted: true,
    type: String,
    default: "",
  });
}

export function getFocusPickerCustomCompendiumKey() {
  try {
    const keys = parseCompendiumPackKeys(
      game.settings.get(MODULE_ID, FOCUS_PICKER_CUSTOM_COMPENDIUM_SETTING) ??
        "",
    );
    return keys[0] ?? "";
  } catch (_) {
    return "";
  }
}

export function getFocusPickerCustomCompendiumKeys() {
  try {
    return parseCompendiumPackKeys(
      game.settings.get(MODULE_ID, FOCUS_PICKER_CUSTOM_COMPENDIUM_SETTING) ??
        "",
    );
  } catch (_) {
    return [];
  }
}

export const TALENT_PICKER_CUSTOM_COMPENDIUM_SETTING =
  "talentPickerCustomCompendium";

export const TALENT_PICKER_INCLUDE_BUILTIN_SETTING =
  "talentPickerIncludeBuiltin";

export function registerTalentPickerSettings() {
  game.settings.register(MODULE_ID, TALENT_PICKER_CUSTOM_COMPENDIUM_SETTING, {
    name: t("sta-officers-log.settings.talentPickerCustomCompendium.name"),
    hint: t("sta-officers-log.settings.talentPickerCustomCompendium.hint"),
    scope: "world",
    config: false,
    restricted: true,
    type: String,
    default: "",
  });

  game.settings.register(MODULE_ID, TALENT_PICKER_INCLUDE_BUILTIN_SETTING, {
    name: t("sta-officers-log.settings.talentPickerIncludeBuiltin.name"),
    hint: t("sta-officers-log.settings.talentPickerIncludeBuiltin.hint"),
    scope: "world",
    config: false,
    restricted: true,
    type: Boolean,
    default: true,
  });
}

export function registerCompendiumPickerMenu() {
  game.settings.registerMenu(MODULE_ID, "compendiumPickerSettings", {
    name:
      t("sta-officers-log.settings.compendiumPicker.name") ||
      "Picker Compendiums",
    label: t("sta-officers-log.settings.compendiumPicker.label") || "Configure",
    hint:
      t("sta-officers-log.settings.compendiumPicker.hint") ||
      "Configure the compendium packs used as custom sources for the Focus and Talent pickers.",
    icon: "fa-solid fa-book-open",
    type: CompendiumPickerSettingsApp,
    restricted: true,
  });
}

export function getTalentPickerCustomCompendiumKey() {
  try {
    const keys = parseCompendiumPackKeys(
      game.settings.get(MODULE_ID, TALENT_PICKER_CUSTOM_COMPENDIUM_SETTING) ??
        "",
    );
    return keys[0] ?? "";
  } catch (_) {
    return "";
  }
}

export function getTalentPickerCustomCompendiumKeys() {
  try {
    return parseCompendiumPackKeys(
      game.settings.get(MODULE_ID, TALENT_PICKER_CUSTOM_COMPENDIUM_SETTING) ??
        "",
    );
  } catch (_) {
    return [];
  }
}

// When false, the built-in STA talent packs are excluded and only the
// configured custom compendiums are searched.
export function getTalentPickerIncludeBuiltinEnabled() {
  try {
    return Boolean(
      game.settings.get(MODULE_ID, TALENT_PICKER_INCLUDE_BUILTIN_SETTING),
    );
  } catch (_) {
    return true;
  }
}
